#!/usr/bin/env python3
"""
P1 화제 재료 — 그 성분의 최근 네이버 뉴스·블로그 제목을 모은다.

# 왜 필요한가

화제를 찾는 곳과 재는 곳이 같아야 한다. 검색량·뉴스 속도는 네이버로 재는데(`naver_trend.py`),
화제를 미국 지역 웹 검색으로 찾으면 해외에서 뜬 주제가 후보로 올라와 「검색량 적음」으로 떨어지고,
AI 가 지어낸 검색어는 한국 사람이 실제로 치는 말과 달라 검색량이 작게 나온다.
그래서 먼저 네이버의 최근 글 제목을 모아 `trend-scout` 에게 준다. 화제 주제와 검색할 말은
**이 제목들에 실제로 나온 표현**에서 고른다.

# 무엇을 모으나

| 종류 | 검색 | 정렬 | 기간 |
|---|---|---|---|
| 뉴스 | `<성분>` · `<성분> 연구` | 최신순 100건씩 | 최근 `--days`일(기본 60) |
| 블로그 | `<성분> 연구 결과` | 최신순 100건 | 최근 `--days`일 |

블로그는 하루에도 수백 건이 올라와 성분 이름만으로 받으면 광고성 글이 대부분이다. 「연구 결과」를 붙이면
「오메가3가 안구건조에 도움 될까?」처럼 소비자가 궁금해하는 화제가 남는다 (정확도순은 오래된 글뿐이라 쓰지 않는다).
뉴스에도 운세·회사 홍보처럼 관계없는 글이 섞인다 — 걸러내는 것은 `trend-scout` 가 한다. 같은 글은 주소로 한 번만 담고,
제목의 `<b>` 같은 표시는 지운다. 제목 · 날짜 · 요약 앞부분 · 주소만 담는다 — 본문은 담지 않는다.

# 사용법

    python3 naver_titles.py <성분> <출력.json> [--days 60]

키는 `naver_trend.py` 와 같다 (`NAVER_CLIENT_ID` · `NAVER_CLIENT_SECRET`, NAVER API HUB 에서 「뉴스」·「블로그」
API 를 켠 것). **키가 없거나 API 가 꺼져 있어도 멈추지 않는다** — `제목` 을 비우고 `안내` 를 적어 exit 0.
그때 `trend-scout` 는 웹 검색만으로 찾는다.

exit 0 성공 또는 키·API 없음 / 2 입력 오류
"""

import argparse
import datetime as dt
import html
import json
import os
import re
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from naver_trend import SearchError, post_date, search_api, write  # noqa: E402

TAG_RE = re.compile(r"<[^>]+>")


def clean(text):
    return re.sub(r"\s+", " ", html.unescape(TAG_RE.sub("", text or ""))).strip()


def collect(kind, query, sort, since, today, cid, secret, seen, label):
    data = search_api(kind, {"query": query, "display": 100, "start": 1, "sort": sort}, cid, secret)
    out = []
    for it in data.get("items") or []:
        try:
            day = post_date(it)
        except (ValueError, TypeError, IndexError):
            continue
        if day is None or not (since <= day <= today):
            continue
        link = it.get("originallink") or it.get("link")
        if not link or link in seen:
            continue
        seen.add(link)
        out.append({"종류": label, "날짜": day.isoformat(), "제목": clean(it.get("title")),
                    "요약": clean(it.get("description"))[:160], "주소": link,
                    "검색어": query})
    time.sleep(0.1)
    return out


def main():
    ap = argparse.ArgumentParser(description="성분의 최근 네이버 뉴스·블로그 제목")
    ap.add_argument("ingredient")
    ap.add_argument("out_file")
    ap.add_argument("--days", type=int, default=60)
    ap.add_argument("--today", help="기준일 YYYY-MM-DD (시험용)")
    a = ap.parse_args()
    if not a.ingredient.strip():
        print("[오류] 성분 이름이 비어 있습니다", file=sys.stderr)
        sys.exit(2)
    today = dt.date.fromisoformat(a.today) if a.today else dt.date.today()
    since = today - dt.timedelta(days=a.days)
    result = {"성분": a.ingredient, "기간": {"시작": since.isoformat(), "끝": today.isoformat()},
              "제목": [], "안내": None}

    cid, secret = os.environ.get("NAVER_CLIENT_ID"), os.environ.get("NAVER_CLIENT_SECRET")
    if not cid or not secret:
        result["안내"] = "네이버 키가 없어 제목을 모으지 않았습니다 — 웹 검색만으로 화제를 찾습니다"
    else:
        seen = set()
        try:
            for q in (a.ingredient, f"{a.ingredient} 연구"):
                result["제목"] += collect("news", q, "date", since, today, cid, secret, seen, "뉴스")
            result["제목"] += collect("blog", f"{a.ingredient} 연구 결과", "date", since, today, cid, secret, seen, "블로그")
        except SearchError as e:
            result["제목"] = []
            result["안내"] = f"네이버 뉴스·블로그를 쓰지 못해 제목을 모으지 않았습니다 — 웹 검색만으로 화제를 찾습니다. {e}"
    result["제목"].sort(key=lambda x: x["날짜"], reverse=True)
    write(a.out_file, result)
    if result["안내"]:
        print(f"[안내] {result['안내']}")
    n_news = sum(1 for t in result["제목"] if t["종류"] == "뉴스")
    print(f"제목 {len(result['제목'])}개 (뉴스 {n_news} · 블로그 {len(result['제목']) - n_news}, "
          f"{since.isoformat()} ~ {today.isoformat()})")
    print(f"→ {a.out_file}")


if __name__ == "__main__":
    main()
