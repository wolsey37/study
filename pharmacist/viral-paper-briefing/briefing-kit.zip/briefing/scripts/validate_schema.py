#!/usr/bin/env python3
"""
P3/P4 출력 스키마 검증기 — 프롬프트 지시를 기계로 집행한다.

# 왜 필요한가

에이전트 정의 파일(.md)에 "이 필드를 반드시 옮겨라"라고 적어도,
그것은 자연어 지시일 뿐이다. 실제로 이런 일이 있었다 — p4-content-scorer.md
가 "`방향`을 반드시 그대로 옮겨 담아라"라고 명시했는데도, 실행된
`점수-*.json`에는 `방향` 필드가 없었다. brief-writer는 그 필드가
없으니 초록을 다시 읽고 **스스로 재판정**했고, 그 결과 후보 파일에서
`mixed`였던 논문이 최종 브리핑에서 `negative`로 바뀌었다.

자연어 지시가 지켜지지 않아도 다음 단계가 조용히 우회한다는 것이
문제다. 이 스크립트는 그 우회로를 막는다 — 필수 필드가 없으면
**여기서 멈춘다.** brief-writer 단계에서는 다시 판정할 필요가
없다는 것을 스키마가 보장한다.

# 사용법

    python3 validate_schema.py candidates <파일...>                        # P3.5
    python3 validate_schema.py scored <점수.json> --candidates <후보...>     # P4.5
    python3 validate_schema.py product <파일...>                           # P0
    python3 validate_schema.py review <검토.json> [--audit <숫자대조.json>]  # P7

`--candidates` 를 주면 채점이 후보의 `방향` · `대상자` 를 바꾸지 않았는지, 빠지거나
끼어든 논문이 없는지 대조한다. `--audit` 을 주면 숫자 대조 오류가 전부 `높음`
지적으로 옮겨졌는지 본다.

실패하면 어떤 파일의 어떤 논문에 어떤 필드가 왜 문제인지 찍고
exit 2 (사용법이 틀려도 argparse 가 exit 2). 통과하면 exit 0. 커맨드(.claude/commands/브리핑.md)가 단계 사이에
이 스크립트를 끼워 넣어, 실패하면 다음 단계로 넘어가지 않는다.
"""

import argparse
import json
import os
import re
import sys
import unicodedata

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from verify_numbers import check_value_in_quote, strip_thousands  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

VALID_DIRECTIONS = {"positive", "mixed", "negative", None}
VALID_DESIGNS = {"meta-analysis", "systematic-review", "rct", "observational",
                 "review", "animal", "in-vitro", "other", None}

# 논문 대상자. paper-hunter 가 초록에서 뽑고 content-scorer 가 계정
# 오디언스와 대조한다. 값은 null 이어도 되지만 **키는 셋 다 있어야**
# 한다 — 키가 없으면 「초록에 없었다」와 「뽑기를 빼먹었다」를 구분할 수 없다.
SUBJECT_KEYS = {"성별", "연령", "상태"}

# p4-content-scorer.md 의 경고 플래그 표와 맞춘다.
VALID_WARNINGS = {"근거약함", "성분불일치", "지침배치", "표시광고", "단일연구", "소규모"}

# 오디언스적합 배점. p4-content-scorer.md 의 표와 맞춘다.
VALID_AUDIENCE_SCORES = {0, 10, 15, 25}

# 콘텐츠 적합도 — 축마다 줄 수 있는 점수. p4-content-scorer.md 의 배점표와 맞춘다.
VALID_AXIS_SCORES = {
    "숫자가용성": {30, 20, 8, 0},
    "의외성": {25, 18, 10},
    "오디언스적합": VALID_AUDIENCE_SCORES,
    "최신성": {20, 14, 8, 3},
}
WEAK_EVIDENCE_MIN_TOTAL = 70          # 근거약함은 총점 70 이상일 때만 붙는다


def expected_recency(age):
    """최신성 — 햇수 = 채점 연도 − 출판연도. p4-content-scorer.md 배점표와 맞춘다."""
    return 20 if age <= 2 else 14 if age <= 5 else 8 if age <= 10 else 3


REASON_REQUIRED = {"근거약함", "지침배치", "표시광고"}


def check_subject(p, where, errors):
    if "대상자" not in p:
        errors.append(f"{where}: 대상자 필드 자체가 없음 (값이 null이어도 키는 있어야 함)")
        return
    s = p["대상자"]
    if not isinstance(s, dict):
        errors.append(f"{where}: 대상자가 객체가 아님 ({s!r})")
        return
    missing = SUBJECT_KEYS - set(s)
    if missing:
        errors.append(f"{where}: 대상자에 {sorted(missing)} 키가 없음")


# 주제 하나당 채굴 대상 상한. p3-paper-hunter.md 의 "최대 15편, 그중 마지막 3자리는
# 시의성" 규칙과 맞춘다 — 여기서 어긋나면 그 규칙이 실제로는 안 지켜지고 있다는 뜻이다.
MAX_CANDIDATES_PER_ANGLE = 15
MAX_TIMELY = 3


def fail(msg):
    print(f"[스키마 오류] {msg}", file=sys.stderr)


def validate_candidates_file(path):
    errors = []
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        return [f"{path}: 파일을 읽거나 파싱할 수 없음 ({e})"]

    papers = data.get("논문")
    if not isinstance(papers, list):
        return [f"{path}: '논문' 필드가 배열이 아님"]

    # 주제 머리 — 채점이 이 값을 주제정보로 그대로 옮기고, 원고가 등급·「추론한 주제」 표시에 쓴다
    if not (isinstance(data.get("주제"), str) and data["주제"].strip()):
        errors.append(f"{path}: 주제 없음")
    for k, allowed in (("근거등급", VALID_GRADES), ("검색정확도", VALID_ACCURACY), ("주제출처", VALID_TOPIC_SOURCES)):
        if data.get(k) not in allowed:
            errors.append(f"{path}: {k}={data.get(k)!r} — {sorted(allowed)} 중 하나")

    # "최대 15편" 규칙은 판정 재료로 받는 전체 편수를 말한다 —
    # off_target·철회는 받은 뒤에 걸러내는 것이므로 제외하면 안 된다.
    # 시의성 자리(13~15번)도 이 15편 안에 있다. 실제로 18편(15편 + 시의성
    # 표시 없는 3편)이 그대로 지나간 적이 있다.
    timely = [p for p in papers if p.get("선정경로") == "시의성"]
    if len(papers) > MAX_CANDIDATES_PER_ANGLE:
        errors.append(f"{path}: 논문이 {len(papers)}편 — 상한 {MAX_CANDIDATES_PER_ANGLE}편을 넘음 "
                      "(p3-paper-hunter.md 의 15편 규칙. 시의성 자리도 이 안에 있다)")
    if len(timely) > MAX_TIMELY:
        errors.append(f"{path}: 시의성 자리가 {len(timely)}편 — {MAX_TIMELY}편까지")

    for i, p in enumerate(papers):
        where = f"{path} [{i}] pmid={p.get('pmid')!r}"

        if not p.get("pmid"):
            errors.append(f"{where}: pmid 없음")

        # "방향" 키가 아예 없는 것과 "방향: null"은 다르다. 전자는
        # 필드를 통째로 빼먹은 버그이고, 후자는 p3-paper-hunter.md가
        # 허용하는 "판정 불가"다. dict.get()은 둘을 구분하지 못하므로
        # 먼저 키 존재를 확인한다.
        if "방향" not in p:
            errors.append(f"{where}: 방향 필드 자체가 없음 (null이 아니라 키가 없음)")
        elif p["방향"] not in VALID_DIRECTIONS:
            errors.append(f"{where}: 방향={p['방향']!r} — "
                           f"{sorted(d for d in VALID_DIRECTIONS if d)} 중 하나(또는 null)여야 함")

        design = p.get("설계")
        if design not in VALID_DESIGNS:
            errors.append(f"{where}: 설계={design!r} — 정의된 값 밖")

        # 채점 대상이 되는 논문만 대상자를 요구한다. off-target·철회는
        # 어차피 채점하지 않는다.
        if not p.get("off_target") and not p.get("배제사유"):
            check_subject(p, where, errors)

        if p.get("off_target") and p.get("배제사유"):
            errors.append(f"{where}: off_target과 배제사유가 동시에 있음 — "
                           "철회는 off_target이 아니라 배제사유만 써야 함")

    return errors


TOPIC_KEYS = ("근거등급", "검색정확도", "주제출처")
VALID_GRADES = {"S1", "S2", "S3", "S4"}
VALID_ACCURACY = {"높음", "보통", "낮음", "미확인"}      # p3-paper-hunter.md 「검색정확도」
VALID_TOPIC_SOURCES = {"사전", "트렌드", "임시"}
# 채점이 후보에서 그대로 옮기는 칸. 바뀌면 원고의 링크·연도·표본이 후보와 달라진다
COPIED_KEYS = ("제목", "설계", "연도", "저널", "doi", "표본", "연평균인용", "오픈액세스")


def _norm(x):
    return " ".join(unicodedata.normalize("NFKC", str(x)).replace("\u2212", "-").split())


def check_effect_slot(effect, where):
    """P5 전에 기계로 볼 수 있는 것 — 값·단위가 인용문 안에 있나, 값이 p값은 아닌가.
    여기서 잡으면 채점을 고쳐 부를 수 있다. P5까지 가면 숫자가 통째로 폐기된다.
    판정은 P5(verify_numbers.py)와 같은 함수를 쓴다."""
    quote = effect.get("quote")
    if not isinstance(quote, str) or not quote.strip():
        return [f"{where}: 효과크기.quote 가 비어 있음 — 인용문이 없으면 효과크기를 null 로"]
    unit = effect.get("unit")
    problem = check_value_in_quote(effect.get("value"), unit if isinstance(unit, str) else None, quote)
    if problem:
        return [f"{where}: 효과크기 value={effect.get('value')!r} unit={unit!r} — {problem}"]
    return []


def load_candidates(paths):
    """후보 파일들 → ({(주제, pmid): 논문} 채점 대상, {(주제, pmid): 논문} 걸러진 것,
    {주제: 주제정보}, 오류). 같은 논문이 두 주제에 나오면 주제마다 따로 둔다 —
    한 주제에서는 채점 대상이고 다른 주제에서는 off-target 일 수 있다."""
    keep, dropped, topics, errors = {}, {}, {}, []
    for path in paths or []:
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, json.JSONDecodeError) as e:
            errors.append(f"{path}: 후보 파일을 읽을 수 없음 ({e})")
            continue
        topic = data.get("주제")
        topics[topic] = {k: data.get(k) for k in TOPIC_KEYS}
        for p in data.get("논문", []) if isinstance(data.get("논문"), list) else []:
            target = dropped if (p.get("off_target") or p.get("배제사유")) else keep
            target[(topic, str(p.get("pmid")))] = p
    return keep, dropped, topics, errors


def validate_scored_file(path, candidates=None):
    errors = []
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        return [f"{path}: 파일을 읽거나 파싱할 수 없음 ({e})"]

    papers = data.get("논문")
    if not isinstance(papers, list):
        return [f"{path}: '논문' 필드가 배열이 아님"]

    # 주제별 근거등급 — 주제가 둘이면 등급도 둘이다. 하나로 합치면 다른 주제의 등급이 붙는다
    info = data.get("주제정보")
    used_topics = {p.get("출처주제") for p in papers if isinstance(p.get("출처주제"), str) and p.get("출처주제")}
    if not isinstance(info, dict):
        errors.append(f"{path}: 주제정보가 없음 — 후보 파일 머리의 근거등급·검색정확도·주제출처를 주제마다 옮길 것")
        info = {}
    for t in sorted(used_topics):
        ti = info.get(t)
        if not isinstance(ti, dict):
            errors.append(f"{path}: 주제정보에 「{t}」 가 없음")
            continue
        if ti.get("근거등급") not in VALID_GRADES:
            errors.append(f"{path}: 주제정보[{t}].근거등급={ti.get('근거등급')!r} — S1~S4")
        if candidates is not None:
            src = candidates[2].get(t)
            if src is None:
                errors.append(f"{path}: 출처주제 「{t}」 의 후보 파일이 --candidates 에 없음")
            else:
                for k in TOPIC_KEYS:
                    if ti.get(k) != src.get(k):
                        errors.append(f"{path}: 주제정보[{t}].{k} 가 후보 {src.get(k)!r} → 채점 {ti.get(k)!r} 로 바뀜")

    required_score_axes = set(VALID_AXIS_SCORES)
    m = re.match(r"(\d{4})-\d{2}-\d{2}$", str(data.get("채점일") or ""))
    score_year = int(m.group(1)) if m else None
    if score_year is None:
        errors.append(f"{path}: 채점일이 YYYY-MM-DD 가 아님 ({data.get('채점일')!r}) — 최신성 햇수를 셀 수 없음")
    totals = [p.get("총점") for p in papers if isinstance(p.get("총점"), (int, float))]
    if totals != sorted(totals, reverse=True):
        errors.append(f"{path}: 논문이 총점 내림차순이 아님")

    for i, p in enumerate(papers):
        where = f"{path} [{i}] pmid={p.get('pmid')!r}"

        if not p.get("pmid"):
            errors.append(f"{where}: pmid 없음")

        # 이게 이번에 유실됐던 필드다. brief-writer가 밀 소재/방어
        # 소재를 가르는 유일한 근거이므로 필수로 강제한다. 키 자체가
        # 없는 것과 명시적 null을 구분해야 한다 — dict.get()만 쓰면
        # 둘 다 None으로 보여서 "필드를 통째로 빼먹었다"를 못 잡는다.
        # 실제로 이 필드가 통째로 없었던 산출물이 있었다.
        if "방향" not in p:
            errors.append(
                f"{where}: 방향 필드 자체가 없음. 필수 필드다. "
                "이게 없으면 brief-writer가 초록을 다시 읽고 스스로 재판정하게 되고, "
                "실제로 그렇게 재판정된 사례가 있었다 (mixed → negative로 뒤바뀜)."
            )
        elif p["방향"] not in VALID_DIRECTIONS:
            errors.append(f"{where}: 방향={p['방향']!r} — 정의된 값 밖")

        if not isinstance(p.get("총점"), (int, float)):
            errors.append(f"{where}: 총점이 숫자가 아님 ({p.get('총점')!r})")

        scores = p.get("점수")
        if not isinstance(scores, dict):
            errors.append(f"{where}: 점수 필드가 없음 — 콘텐츠 적합도 네 축 {sorted(required_score_axes)}")
        elif set(scores) != required_score_axes:
            missing, extra = required_score_axes - set(scores), set(scores) - required_score_axes
            errors.append(f"{where}: 점수 축이 배점표와 다름 — 빠진 축 {sorted(missing)} · 배점표에 없는 축 {sorted(extra)}"
                          " (콘텐츠 적합도: 숫자가용성·의외성·오디언스적합·최신성)")

        if isinstance(scores, dict) and set(scores) == required_score_axes:
            for ax, allowed in VALID_AXIS_SCORES.items():
                if scores[ax] not in allowed:
                    errors.append(f"{where}: {ax}={scores[ax]!r} — {sorted(allowed)} 중 하나여야 함")
            if isinstance(p.get("총점"), (int, float)) and all(
                    isinstance(v, (int, float)) for v in scores.values()) and sum(scores.values()) != p["총점"]:
                errors.append(f"{where}: 총점 {p['총점']} ≠ 다섯 축의 합 {sum(scores.values())}")
            year = p.get("연도")
            age = score_year - year if score_year and isinstance(year, int) else None
            if age is not None and scores.get("최신성") != expected_recency(age):
                errors.append(f"{where}: 최신성={scores.get('최신성')} — 연도 {year}, 햇수 {age} 이면 "
                              f"{expected_recency(age)}")
            if scores.get("숫자가용성") in (30, 20) and not p.get("효과크기"):
                errors.append(f"{where}: 숫자가용성={scores['숫자가용성']} 인데 효과크기가 null — "
                              "수치가 없으면 p값만=8 또는 없음=0")

        check_subject(p, where, errors)

        # 오디언스적합은 주제 소속이 아니라 **논문 대상자 × 계정 오디언스**
        # 로 매긴다. 근거 문장이 없으면 그 판정이 대상자를 봤는지 알 수 없다.
        if isinstance(scores, dict) and "오디언스적합" in scores:
            if scores["오디언스적합"] not in VALID_AUDIENCE_SCORES:
                errors.append(f"{where}: 오디언스적합={scores['오디언스적합']!r} — "
                              f"{sorted(VALID_AUDIENCE_SCORES)} 중 하나여야 함")
        reason = p.get("오디언스근거")
        if not isinstance(reason, str) or not reason.strip():
            errors.append(f"{where}: 오디언스근거가 없음 — 대상자와 계정 오디언스를 "
                          "어떻게 대조했는지 한 문장으로 적어야 함")

        if not (isinstance(p.get("출처주제"), str) and p["출처주제"].strip()):
            errors.append(f"{where}: 출처주제가 문자열 하나가 아님 ({p.get('출처주제')!r}) — brief-writer 가 "
                          "주력주제 순으로 배치하려면 어느 주제에서 왔는지 알아야 함. 다른 주제는 다른출처주제에")
        other = p.get("다른출처주제")
        if other is not None and not (isinstance(other, list) and all(isinstance(x, str) for x in other)):
            errors.append(f"{where}: 다른출처주제는 문자열 배열이어야 함 ({other!r})")

        effect = p.get("효과크기")
        if effect is not None:
            if not isinstance(effect, dict):
                errors.append(f"{where}: 효과크기가 dict도 null도 아님")
            elif effect.get("verified") is not None:
                errors.append(f"{where}: 효과크기.verified={effect.get('verified')!r} — 채점 단계에서는 "
                               "null 이어야 함. 채우는 것은 P5 verify_numbers.py 다")
            else:
                errors.extend(check_effect_slot(effect, where))

        # 경고는 **라벨만** 적는다. 「근거약함 — 표본 80명…」처럼 이유를 붙이면
        # 요약의 근거약함 편수가 실제보다 적게 세어진다 (실제로 4편이 1편으로
        # 나왔다). 이유는 `경고이유` 에 라벨별로 적는다.
        warnings = p.get("경고")
        if warnings is not None and not isinstance(warnings, list):
            errors.append(f"{where}: 경고 필드가 배열이 아님")
        elif warnings:
            bad = [w for w in warnings if not isinstance(w, str) or w not in VALID_WARNINGS]
            if bad:
                errors.append(f"{where}: 경고에 라벨이 아닌 값 {bad!r} — "
                              f"{sorted(VALID_WARNINGS)} 중에서만 적고, 이유는 `경고이유` 에 적을 것")
        reasons = p.get("경고이유")
        if reasons is not None:
            if not isinstance(reasons, dict):
                errors.append(f"{where}: 경고이유가 객체가 아님 (라벨 → 이유)")
            elif set(reasons) - set(warnings or []):
                errors.append(f"{where}: 경고이유에 경고에 없는 라벨 {sorted(set(reasons) - set(warnings or []))}")
        if isinstance(warnings, list):
            given = reasons if isinstance(reasons, dict) else {}
            for label in sorted(REASON_REQUIRED & set(warnings)):
                if not (isinstance(given.get(label), str) and given[label].strip()):
                    errors.append(f"{where}: 경고 {label} 의 이유가 `경고이유` 에 없음")
            if "근거약함" in warnings and isinstance(p.get("총점"), (int, float)) \
                    and p["총점"] < WEAK_EVIDENCE_MIN_TOTAL:
                errors.append(f"{where}: 총점 {p['총점']} 에 근거약함 — {WEAK_EVIDENCE_MIN_TOTAL}점 이상일 때만 붙인다")

        # 후보와 대조 — 채점은 방향·대상자를 옮기기만 한다. 다시 판정하면 여기서 걸린다.
        # 실제로 후보에서 null 이던 방향이 채점 파일에서 positive 가 되어 원고에 실린 적이 있다.
        if candidates is not None:
            keep, dropped = candidates[0], candidates[1]
            key = (p.get("출처주제"), str(p.get("pmid")))
            c = keep.get(key) if isinstance(key[0], str) else None
            if c is None:
                if key in dropped:
                    why = f"주제 「{key[0]}」 후보에서 걸러진 논문(off_target·배제사유)"
                elif any(k[1] == key[1] for k in keep):
                    why = f"출처주제 「{key[0]}」 의 후보에 없는 논문 (다른 주제의 후보다)"
                else:
                    why = "후보 파일에 없는 논문"
                errors.append(f"{where}: {why} 이 채점에 들어옴")
            else:
                if "방향" in p and p.get("방향") != c.get("방향"):
                    errors.append(f"{where}: 방향이 후보 {c.get('방향')!r} → 채점 {p.get('방향')!r} 로 바뀜 — "
                                  "채점은 방향을 다시 판정하지 않는다")
                if p.get("대상자") != c.get("대상자"):
                    errors.append(f"{where}: 대상자가 후보와 다름")
                for k in COPIED_KEYS:
                    if k in c and p.get(k) != c.get(k):
                        errors.append(f"{where}: {k} 가 후보 {c.get(k)!r} → 채점 {p.get(k)!r} — 후보 값을 그대로 옮길 것")

    if candidates is not None:
        scored_ids = {str(p.get("pmid")) for p in papers}
        missing = sorted({k[1] for k in candidates[0]} - scored_ids)
        if missing:
            errors.append(f"{path}: 후보의 채점 대상 논문 {len(missing)}편이 빠짐 {missing}")

    return errors


VALID_SOURCE_GRADES = {"신고정보", "제조사", "판매처", "기사"}


def validate_product_file(path):
    """P0 제품 파일. 식약처 조회(product_lookup.py)와 웹 검색(product-reader)이
    같은 형식을 쓴다. 제품 표시값은 PubMed 대조를 거치지 않으므로, **함량마다
    원문이 붙어 있는지**가 이 값을 믿을 유일한 근거다."""
    errors = []
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        return [f"{path}: 파일을 읽거나 파싱할 수 없음 ({e})"]

    cands = data.get("후보")
    if not isinstance(cands, list):
        return [f"{path}: '후보' 필드가 배열이 아님"]
    ids = set()
    for i, c in enumerate(cands):
        where = f"{path} 후보[{i}] {c.get('제품명')!r}"
        if not c.get("제품명"):
            errors.append(f"{where}: 제품명 없음")
        if not c.get("신고번호"):
            errors.append(f"{where}: 신고번호 없음 (웹 후보는 '웹-1' 처럼 번호를 붙일 것)")
        ids.add(str(c.get("신고번호")))
        if not c.get("출처"):
            errors.append(f"{where}: 출처 없음")
        if c.get("출처등급") not in VALID_SOURCE_GRADES:
            errors.append(f"{where}: 출처등급={c.get('출처등급')!r} — {sorted(VALID_SOURCE_GRADES)} 중 하나")
        if not isinstance(c.get("주성분후보"), list):
            errors.append(f"{where}: 주성분후보가 배열이 아님")
        doses = c.get("함량")
        if not isinstance(doses, dict):
            errors.append(f"{where}: 함량이 객체가 아님")
        else:
            for k, v in doses.items():
                if v is not None and not (isinstance(v, dict) and isinstance(v.get("원문"), str) and v["원문"].strip()):
                    errors.append(f"{where}: 함량[{k}] 에 원문이 없음 — 표시 원문 없이 숫자만 적으면 안 됨")
    sel = data.get("선택")
    if sel is not None and str(sel) not in ids:
        errors.append(f"{path}: 선택={sel!r} 가 후보의 신고번호에 없음")
    return errors


VALID_SEVERITIES = {"높음", "중간", "낮음"}
VALID_REVIEW_TYPES = {"출처밖단정", "숫자변형", "효능과장", "과잉일반화", "소재부적합",
                      "경고누락", "금지표현", "기타"}


def _squash(text):
    return " ".join(str(text).split())


def validate_review_file(path, audit=None):
    """P7 검토 파일. `위치` 가 원고에 글자 그대로 있어야 한다 — 없는 문장을
    지적하면 사람이 원고에서 찾을 수 없고, 검토자가 원고를 지어냈다는 뜻이다."""
    errors = []
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        return [f"{path}: 파일을 읽거나 파싱할 수 없음 ({e})"]

    md_path = data.get("원고")
    if isinstance(md_path, str) and not os.path.isabs(md_path) and not os.path.exists(md_path):
        md_path = os.path.join(ROOT, md_path)   # 원고 경로는 프로젝트 폴더 기준으로 적는다
    try:
        with open(md_path, encoding="utf-8") as f:
            md = _squash(f.read())
    except (OSError, TypeError) as e:
        return [f"{path}: 원고={md_path!r} 를 읽을 수 없음 ({e})"]

    items = data.get("지적")
    if not isinstance(items, list):
        return [f"{path}: '지적' 필드가 배열이 아님"]
    for i, it in enumerate(items):
        where = f"{path} 지적[{i}]"
        if it.get("심각도") not in VALID_SEVERITIES:
            errors.append(f"{where}: 심각도={it.get('심각도')!r} — {sorted(VALID_SEVERITIES)} 중 하나")
        if it.get("유형") not in VALID_REVIEW_TYPES:
            errors.append(f"{where}: 유형={it.get('유형')!r} — {sorted(VALID_REVIEW_TYPES)} 중 하나")
        for k in ("근거", "제안"):
            if not (isinstance(it.get(k), str) and it[k].strip()):
                errors.append(f"{where}: {k} 없음")
        loc = it.get("위치")
        if not (isinstance(loc, str) and loc.strip()):
            errors.append(f"{where}: 위치 없음")
        elif _squash(loc) not in md:
            errors.append(f"{where}: 위치 「{loc[:40]}」 가 원고에 없음 — 원고에서 글자 그대로 복사할 것")

    # 숫자 대조 오류는 전부 높음 지적이어야 한다 — 빠지면 출처 없는 숫자가 고쳐 쓰기 없이 HTML까지 간다.
    # 표기 차이(−/-, 전각, 천 단위 쉼표, 공백)로 「옮겼는데 못 찾음」이 되지 않게 양쪽을 같이 접는다
    def fold(x):
        return strip_thousands(_norm(x)).replace(" ", "")
    for e in (audit or {}).get("오류", []):
        num = fold(e.get("숫자", ""))
        covered = any(it.get("심각도") == "높음" and num and
                      (num in fold(it.get("위치", "")) or num in fold(it.get("근거", ""))) for it in items)
        if not covered:
            errors.append(f"{path}: 숫자 대조 오류 {e.get('줄')}행 「{num}」 이 높음 지적으로 옮겨지지 않음")

    has_high = any(it.get("심각도") == "높음" for it in items)
    expected = "수정필요" if has_high else "통과"
    if data.get("판정") != expected:
        errors.append(f"{path}: 판정={data.get('판정')!r} — 높음이 {'있으면' if has_high else '없으면'} {expected!r}")
    return errors


def main():
    ap = argparse.ArgumentParser(description="단계 사이 스키마 검증")
    ap.add_argument("kind", choices=["candidates", "scored", "product", "review"])
    ap.add_argument("paths", nargs="+")
    ap.add_argument("--candidates", nargs="+", help="scored: 대조할 후보 파일들")
    ap.add_argument("--audit", help="review: 숫자 대조 결과 파일")
    a = ap.parse_args()

    all_errors = []
    if a.kind == "scored":
        cands = None
        if a.candidates:
            keep, dropped, topics, errs = load_candidates(a.candidates)
            all_errors += errs
            cands = (keep, dropped, topics)
        for path in a.paths:
            all_errors.extend(validate_scored_file(path, cands))
    elif a.kind == "review":
        audit = None
        if a.audit:
            try:
                with open(a.audit, encoding="utf-8") as f:
                    audit = json.load(f)
            except (OSError, json.JSONDecodeError) as e:
                all_errors.append(f"{a.audit}: 숫자 대조 파일을 읽을 수 없음 ({e})")
        for path in a.paths:
            all_errors.extend(validate_review_file(path, audit))
    else:
        validator = {"candidates": validate_candidates_file, "product": validate_product_file}[a.kind]
        for path in a.paths:
            all_errors.extend(validator(path))

    if all_errors:
        for e in all_errors:
            fail(e)
        print(f"\n{len(all_errors)}건의 스키마 오류. 다음 단계로 넘어가지 마십시오.",
              file=sys.stderr)
        sys.exit(2)

    print(f"스키마 통과: {len(a.paths)}개 파일, {a.kind}")
    sys.exit(0)


if __name__ == "__main__":
    main()
