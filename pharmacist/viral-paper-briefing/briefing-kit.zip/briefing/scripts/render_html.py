#!/usr/bin/env python3
"""
P8 브리핑 HTML 렌더러 — 최종 산출물을 보기 쉬운 한 장으로 만든다.

# 왜 스크립트인가 (brief-writer 가 직접 HTML을 쓰지 않는 이유)

세 가지 때문이다.

1. **모양이 실행마다 달라진다.** brief-writer 가 매 실행마다 CSS를 새로 짜게 하면
   실행마다 브리핑이 서로 다른 모양으로 나온다. 나란히 놓고
   비교하는 것이 이 도구의 목적인데, 모양이 다르면 비교가 어렵다.
2. **디자인을 고칠 때마다 에이전트를 다시 돌려야 한다.** 스타일이
   HTML 안에 박혀 있으면 여백 하나 바꾸려고 논문 채점부터 다시
   하게 된다. 스타일이 이 파일에 있으면 렌더만 다시 돌리면 된다.
3. **토큰이 내용이 아니라 껍데기에 쓰인다.** 400줄짜리 CSS를
   매번 생성하는 값어치가 없다.

그래서 brief-writer 는 계속 마크다운을 쓴다 — 사람이 읽기 쉽고
diff 가 남는다. 이 스크립트가 그것을 HTML로 옮긴다.
P3.5·P4.5·P5 를 스크립트로 둔 것과 같은 이유다.

# 마크다운 규약에 의존한다

p6-brief-writer.md 의 출력 예시에 있는 표기를 그대로 알아본다.

    ✅ 검증됨          → 초록 대조를 통과한 숫자. 초록색 배지
    ⚠ 근거약함         → 경고 배지 (지침배치·표시광고·단일연구·소규모·철회도)
    🔁 이미 씀 <날짜>   → 사용이력 배지 (발행/발행기록.json 에 있는 논문)
    📦 제품 표시값      → 제품 표시값 배지 (PubMed 대조를 거치지 않은 값)
    ## 이 제품 — …      → 제품 절
    **핵심 숫자** — …  → 그 다음 인용블록을 「초록 원문」으로 표시
    ### 후킹 초안       → 복사 버튼이 붙은 카드로
    ## 방어 소재 — …   → 경고색 섹션
    ## 쓰지 않는 것을 권합니다 → 폐기색 섹션
    PMID 12345         → PubMed 링크로 자동 변환
    상단 요약표         → 큰 숫자 타일로

**표기를 바꾸면 여기도 바꿔야 한다.** 알아보지 못한 표기는 버리지
않고 평문으로 그대로 통과시킨다 — 조용히 사라지는 것이 가장 나쁘다.

# 요약 숫자 교차검증

`점수파일`(검증됨 JSON)을 함께 넘기면, 브리핑 상단 요약표의 네
숫자를 JSON 의 `요약` 필드와 대조한다. 어긋나면 exit 3.

p6-brief-writer.md 는 "직접 세지 말고 `요약` 필드를 그대로 옮겨라"라고
적어 두었지만 그것은 자연어 지시다. 실제로 손으로 세다가 어긋난
적이 있다 — "근거약함 없음 8편"이라고 썼는데 실제로는 12편이었다.
이 대조가 그 어긋남을 기계적으로 잡는다.

# 사용법

    python3 render_html.py <원고.md> <출력.html> [점수파일-검증됨.json] [--review 검토.json] [--audit 숫자대조.json]

`--audit` 을 주면, 숫자 대조에서 출처를 못 찾은 숫자가 남아 있을 때 페이지 맨 위에
경고 상자를 띄운다. 고쳐 쓰기를 한 번 하고도 남은 숫자다 — 원문 확인 전에 쓰면 안 된다.

`--review` 를 주면 P7 검토 지적을 맨 끝 「검토 메모」 절로 붙인다. 원고는 고치지
않는다 — 지적이 맞는지는 약사가 판단한다.

exit 0 통과 / 2 입력 오류 / 3 요약 숫자 불일치
"""

import html
import json
import os
import re
import sys

# ---------------------------------------------------------------------------
# 알아보는 표기
# ---------------------------------------------------------------------------

# viral-scorer 가 붙이는 경고 이름. 이 목록에 있는 것만 배지로 만든다.
# "⚠ 이렇게 쓰면 안 됩니다" 같은 안내 문구를 배지로 오인하지 않으려면
# 이름을 열거해야 한다.
WARNING_NAMES = ["근거약함", "성분불일치", "지침배치", "표시광고", "단일연구", "소규모", "철회"]

# 상단 요약표를 숫자 타일로 바꿀지 판단하는 열 이름.
# verify_numbers.py 가 `요약` 필드에 넣는 네 값과 짝이 맞는다.
SUMMARY_COLUMNS = {
    "총 논문수": "총_논문수",
    "경고 없음": "경고_없음",
    "근거약함 포함": "근거약함_포함",
    "효과크기 null": "효과크기_null",
}

SECTION_TONES = [
    ("방어 소재", "defense"),
    ("쓰지 않는 것을 권합니다", "discard"),
    ("마지막 확인", "checklist"),
    ("이번 실행에 대한 안내", "notice"),
    ("이 제품", "notice"),
    ("지금 화제", "trend"),
]

PUBMED = "https://pubmed.ncbi.nlm.nih.gov/{}/"


def die(msg, code=2):
    print(f"[오류] {msg}", file=sys.stderr)
    sys.exit(code)


# ---------------------------------------------------------------------------
# 인라인 서식
# ---------------------------------------------------------------------------

_PLACEHOLDER = "\x00{}\x00"


def inline(text):
    """한 줄짜리 마크다운 인라인 서식을 HTML로 바꾼다.

    코드 스팬과 링크는 먼저 자리표시자로 빼 둔다 — 그 안의 문자열이
    PMID·URL 자동 링크에 두 번 걸리는 것을 막기 위해서다.
    """
    stash = []

    def keep(html_fragment):
        stash.append(html_fragment)
        return _PLACEHOLDER.format(len(stash) - 1)

    # 1) 코드 스팬 — 안의 내용은 서식을 적용하지 않는다
    def on_code(m):
        return keep(f"<code>{html.escape(m.group(1))}</code>")

    text = re.sub(r"`([^`]+)`", on_code, text)

    # 2) 명시적 링크 [글자](주소)
    def on_link(m):
        label, href = m.group(1), m.group(2)
        return keep(
            f'<a href="{html.escape(href, quote=True)}" '
            f'target="_blank" rel="noopener noreferrer">{html.escape(label)}</a>'
        )

    text = re.sub(r"\[([^\]]+)\]\((https?://[^\s)]+)\)", on_link, text)

    # 3) 남은 평문을 이스케이프
    text = html.escape(text)

    # 4) 맨 URL → 링크. 문장 끝 마침표·괄호는 링크에서 뺀다
    def on_bare_url(m):
        url = m.group(0)
        trail = ""
        while url and url[-1] in ").,;·":
            trail = url[-1] + trail
            url = url[:-1]
        return (
            f'<a href="{url}" target="_blank" rel="noopener noreferrer" '
            f'class="url">{url}</a>{trail}'
        )

    text = re.sub(r"https?://[^\s<]+", on_bare_url, text)

    # 5) PMID → PubMed 링크
    def on_pmid(m):
        pmid = m.group(1)
        return (
            f'<a href="{PUBMED.format(pmid)}" target="_blank" rel="noopener noreferrer" '
            f'class="pmid">PMID {pmid}</a>'
        )

    text = re.sub(r"\bPMID\s+(\d{6,9})\b", on_pmid, text)

    # 6) 강조
    text = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", text)

    # 7) 배지
    text = text.replace(
        "✅ 검증됨", '<span class="badge ok">✅ 검증됨</span>'
    )
    for name in WARNING_NAMES:
        text = re.sub(
            r"⚠\s*" + re.escape(name),
            # 배지 안의 기호는 엔티티로 쓴다. 아래 「남은 ⚠」 치환이
            # 배지 안의 ⚠ 까지 다시 감싸 span 이 중첩되는 것을 막는다
            f'<span class="badge warn">&#9888; {name}</span>',
            text,
        )
    text = re.sub(
        r"🔁\s*이미 씀(\s*\d{4}-\d{2}-\d{2})?",
        lambda m: f'<span class="badge used">🔁 이미 씀{m.group(1) or ""}</span>',
        text,
    )
    text = text.replace("📦 제품 표시값", '<span class="badge label">📦 제품 표시값</span>')
    # 남은 ⚠ 는 배지가 아니라 강조 표시로 둔다
    text = text.replace("⚠", '<span class="warn-mark">⚠</span>')

    # 8) 자리표시자 복원
    def restore(m):
        return stash[int(m.group(1))]

    return re.sub(r"\x00(\d+)\x00", restore, text)


def plain(text):
    """서식을 벗긴 순수 텍스트. 목차와 복사 버튼에 쓴다."""
    text = re.sub(r"`([^`]+)`", r"\1", text)
    text = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", text)
    text = re.sub(r"\*\*([^*]+)\*\*", r"\1", text)
    return text.strip()


# ---------------------------------------------------------------------------
# 블록 파서
# ---------------------------------------------------------------------------


def parse_blocks(lines):
    """마크다운을 블록 리스트로 만든다. 알아보지 못한 줄은 문단으로 둔다."""
    blocks = []
    i = 0
    n = len(lines)

    while i < n:
        raw = lines[i]
        line = raw.rstrip()

        if not line.strip():
            i += 1
            continue

        # 수평선
        if re.fullmatch(r"-{3,}", line.strip()):
            blocks.append({"type": "hr"})
            i += 1
            continue

        # 제목
        m = re.match(r"^ {0,3}(#{1,6})\s+(.*)$", line)   # 마크다운처럼 앞 공백 3칸까지는 제목
        if m:
            blocks.append(
                {"type": "heading", "level": len(m.group(1)), "text": m.group(2).strip()}
            )
            i += 1
            continue

        # 인용블록 — 연속된 > 줄을 하나로 모은다
        if line.lstrip().startswith(">"):
            buf = []
            while i < n and lines[i].strip().startswith(">"):
                buf.append(re.sub(r"^\s*>\s?", "", lines[i].rstrip()))
                i += 1
            blocks.append({"type": "quote", "lines": buf})
            continue

        # 표 — | 로 시작하는 연속 줄
        if line.lstrip().startswith("|"):
            rows = []
            while i < n and lines[i].strip().startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                rows.append(cells)
                i += 1
            blocks.append({"type": "table", "rows": rows})
            continue

        # 순서 있는 목록
        if re.match(r"^\s*\d+\.\s+", line):
            items = []
            while i < n and re.match(r"^\s*\d+\.\s+", lines[i].rstrip()):
                items.append(re.sub(r"^\s*\d+\.\s+", "", lines[i].rstrip()))
                i += 1
                # 목록 항목의 이어지는 줄(들여쓰기)을 붙인다
                while (
                    i < n
                    and lines[i].strip()
                    and lines[i].startswith("  ")
                    and not re.match(r"^\s*\d+\.\s+", lines[i].rstrip())
                    and not lines[i].strip().startswith(("-", "|", ">", "#"))
                ):
                    items[-1] += " " + lines[i].strip()
                    i += 1
            blocks.append({"type": "ol", "items": items})
            continue

        # 순서 없는 목록
        if re.match(r"^\s*[-*]\s+", line):
            items = []
            while i < n and re.match(r"^\s*[-*]\s+", lines[i].rstrip()):
                items.append(re.sub(r"^\s*[-*]\s+", "", lines[i].rstrip()))
                i += 1
                while (
                    i < n
                    and lines[i].strip()
                    and lines[i].startswith("  ")
                    and not re.match(r"^\s*[-*]\s+", lines[i].rstrip())
                    and not lines[i].strip().startswith(("|", ">", "#"))
                    and not re.match(r"^\s*\d+\.\s+", lines[i].rstrip())
                ):
                    items[-1] += " " + lines[i].strip()
                    i += 1
            blocks.append({"type": "ul", "items": items})
            continue

        # 그 밖에는 문단. 빈 줄까지 모은다
        buf = []
        while i < n and lines[i].strip():
            nxt = lines[i].rstrip()
            # 「#」 뒤에 공백이 있어야 제목이다 — 「#오메가3 #생리통」 같은 해시태그 줄은 문단으로 둔다
            if nxt.lstrip().startswith(("|", ">")) or re.match(r" {0,3}#{1,6}\s", nxt) or re.fullmatch(
                r"-{3,}", nxt.strip()
            ):
                break
            if re.match(r"^\s*([-*]|\d+\.)\s+", nxt) and buf:
                break
            buf.append(nxt.strip())
            i += 1
        if buf:
            blocks.append({"type": "para", "text": " ".join(buf)})
        else:
            i += 1

    return blocks


# ---------------------------------------------------------------------------
# 렌더
# ---------------------------------------------------------------------------


def looks_like_summary(rows):
    if len(rows) < 3:
        return False
    header = [plain(c) for c in rows[0]]
    return sum(1 for h in header if h in SUMMARY_COLUMNS) >= 3


def render_summary(rows):
    header = [plain(c) for c in rows[0]]
    values = rows[2] if len(rows) > 2 else []
    tiles = []
    for idx, label in enumerate(header):
        value = plain(values[idx]) if idx < len(values) else "—"
        tone = ""
        if label == "근거약함 포함":
            tone = " warnish"
        elif label == "경고 없음":
            tone = " okish"
        tiles.append(
            f'<div class="tile{tone}"><div class="tile-v">{html.escape(value)}</div>'
            f'<div class="tile-k">{html.escape(label)}</div></div>'
        )
    return '<div class="tiles">' + "".join(tiles) + "</div>"


def is_spec_table(rows):
    """`| | |` 로 시작하는 2열 키-값 표 (논문 제원표)."""
    return len(rows[0]) == 2 and not any(plain(c) for c in rows[0])


def render_table(rows):
    if looks_like_summary(rows):
        return render_summary(rows)

    body_start = 1
    # 구분선 행(|---|---|)을 건너뛴다
    if len(rows) > 1 and all(re.fullmatch(r":?-{2,}:?", c.strip()) for c in rows[1] if c.strip()):
        body_start = 2

    if is_spec_table(rows):
        out = ['<table class="spec"><tbody>']
        for r in rows[body_start:]:
            if len(r) < 2:
                continue
            # 칸 안의 「|」 때문에 칸이 더 쪼개졌으면 버리지 않고 이어 붙인다
            out.append(
                f"<tr><th>{inline(r[0])}</th><td>{inline(' | '.join(r[1:]))}</td></tr>"
            )
        out.append("</tbody></table>")
        return "".join(out)

    out = ['<div class="tw"><table><thead><tr>']
    for c in rows[0]:
        out.append(f"<th>{inline(c)}</th>")

    out.append("</tr></thead><tbody>")
    for r in rows[body_start:]:
        out.append("<tr>")
        for c in r:
            out.append(f"<td>{inline(c)}</td>")
        out.append("</tr>")
    out.append("</tbody></table></div>")
    return "".join(out)


def render_quote(lines, prev):
    """인용블록. 앞 블록이 무엇이었는지에 따라 성격이 갈린다."""
    # H1 바로 뒤 → 부제. 칩으로 끊는다.
    # 줄마다 따로 끊고, 구분자는 **공백을 낀** 가운뎃점만 본다 —
    # `피부·인지(부차)` 처럼 붙여 쓴 가운뎃점은 한 덩어리로 남긴다
    if prev == "title":
        chips = []
        for line in lines:
            if not line.strip():
                continue
            chips += [c.strip() for c in re.split(r"\s+·\s+", line.strip()) if c.strip()]
        return '<div class="chips">' + "".join(
            f'<span class="chip">{inline(c)}</span>' for c in chips
        ) + "</div>"

    text = " ".join(l.strip() for l in lines if l.strip())

    # 「핵심 숫자」 문단 뒤 → 초록 원문 인용
    if prev == "keynum":
        return (
            '<figure class="abstract"><figcaption>초록 원문</figcaption>'
            f"<blockquote>{inline(text)}</blockquote></figure>"
        )

    return f"<blockquote class=\"note\">{inline(text)}</blockquote>"


def render_hooks(items):
    cards = []
    for it in items:
        label = plain(it).strip().strip('"“”')
        cards.append(
            '<li class="hook">'
            f'<span class="hook-t">{html.escape(label)}</span>'
            f'<button class="copy" type="button" '
            f'data-text="{html.escape(label, quote=True)}">복사</button>'
            "</li>"
        )
    return '<ol class="hooks">' + "".join(cards) + "</ol>"


def slugify(text, used):
    base = re.sub(r"[^0-9A-Za-z가-힣]+", "-", plain(text)).strip("-").lower()
    base = base or "sec"
    slug, k = base, 2
    while slug in used:
        slug = f"{base}-{k}"
        k += 1
    used.add(slug)
    return slug


def section_tone(text):
    for needle, tone in SECTION_TONES:
        if needle in text:
            return tone
    return ""


def render(blocks):
    """블록 리스트 → (본문 HTML, 제목, 목차)."""
    out = []
    toc = []
    used_slugs = set()
    title = "브리핑"
    prev = None          # 인용블록의 성격 판정용
    in_hooks = False     # 「후킹 초안」 제목 직후인가
    open_section = False
    seen_h1 = False

    for b in blocks:
        t = b["type"]

        if t == "heading":
            level, text = b["level"], b["text"]

            if level == 1:
                if not seen_h1:          # 탭 제목은 첫 H1 — 원고에 H1이 여럿이어도
                    title, seen_h1 = plain(text), True
                out.append(f"<h1>{inline(text)}</h1>")
                prev = "title"
                continue

            if level == 2:
                if open_section:
                    out.append("</section>")
                slug = slugify(text, used_slugs)
                tone = section_tone(text)
                toc.append((slug, plain(text), tone))
                cls = f' class="{tone}"' if tone else ""
                out.append(f'<section id="{slug}"{cls}>')
                out.append(f"<h2>{inline(text)}</h2>")
                open_section = True
                in_hooks = False
                prev = "h2"
                continue

            in_hooks = "후킹" in text
            out.append(f"<h{level}>{inline(text)}</h{level}>")
            prev = "h"
            continue

        if t == "para":
            text = b["text"]
            out.append(f"<p>{inline(text)}</p>")
            # 「핵심 숫자」 문단이면 다음 인용블록이 초록 원문이다
            prev = "keynum" if "핵심 숫자" in text else "para"
            continue

        if t == "quote":
            out.append(render_quote(b["lines"], prev))
            prev = "quote"
            continue

        if t == "table":
            out.append(render_table(b["rows"]))
            prev = "table"
            continue

        if t == "ol":
            if in_hooks:
                out.append(render_hooks(b["items"]))
                in_hooks = False
            else:
                out.append(
                    "<ol>" + "".join(f"<li>{inline(x)}</li>" for x in b["items"]) + "</ol>"
                )
            prev = "list"
            continue

        if t == "ul":
            out.append(
                "<ul>" + "".join(f"<li>{inline(x)}</li>" for x in b["items"]) + "</ul>"
            )
            prev = "list"
            continue

        if t == "hr":
            out.append('<hr>')
            prev = "hr"
            continue

    if open_section:
        out.append("</section>")

    return "\n".join(out), title, toc


# ---------------------------------------------------------------------------
# 요약 숫자 교차검증
# ---------------------------------------------------------------------------


def crosscheck_summary(md_lines, scored_path):
    """상단 요약표 숫자를 검증됨 JSON 의 `요약` 필드와 대조한다."""
    try:
        with open(scored_path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        die(f"점수파일을 읽을 수 없습니다: {scored_path} ({e})")

    truth = data.get("요약")
    if not isinstance(truth, dict):
        print(f"[안내] {os.path.basename(scored_path)} 에 `요약` 필드가 없어 "
              f"교차검증을 건너뜁니다")
        return []

    blocks = parse_blocks(md_lines)
    for b in blocks:
        if b["type"] == "table" and looks_like_summary(b["rows"]):
            header = [plain(c) for c in b["rows"][0]]
            values = [plain(c) for c in b["rows"][2]] if len(b["rows"]) > 2 else []
            mismatches = []
            for idx, label in enumerate(header):
                key = SUMMARY_COLUMNS.get(label)
                if key is None or key not in truth:
                    continue
                written = values[idx] if idx < len(values) else ""
                expected = str(truth[key])
                if re.sub(r"[^\d]", "", written) != expected:   # 「12편」도 12 로 본다
                    mismatches.append(f"{label}: 브리핑={written or '(빈칸)'} / 파일={expected}")
            return mismatches

    # 요약표가 없거나 열 이름이 바뀌었으면 대조를 건너뛰지 않고 멈춘다
    return [f"상단 요약표를 찾지 못함 — 열 이름은 {' · '.join(SUMMARY_COLUMNS)} 그대로여야 함"]


# ---------------------------------------------------------------------------
# 페이지 껍데기
# ---------------------------------------------------------------------------

CSS = """
*,*::before,*::after{box-sizing:border-box}
:root{
  --bg:#f6f7f9; --card:#fff; --ink:#15181d; --dim:#5b6472; --line:#e3e7ec;
  --accent:#1f6feb; --accent-soft:#eaf2fe;
  --ok:#116e3f; --ok-soft:#e6f5ec;
  --warn:#8a5300; --warn-soft:#fdf1dd;
  --bad:#9a2c2c; --bad-soft:#fceceb;
  --mono:ui-monospace,SFMono-Regular,"SF Mono",Menlo,Consolas,monospace;
  --sans:-apple-system,BlinkMacSystemFont,"Apple SD Gothic Neo","Pretendard",
         "Malgun Gothic","Segoe UI",Roboto,sans-serif;
}
@media (prefers-color-scheme:dark){
  :root{
    --bg:#0e1116; --card:#161b22; --ink:#e6edf3; --dim:#9aa5b1; --line:#282f39;
    --accent:#58a6ff; --accent-soft:#14243d;
    --ok:#5fd39a; --ok-soft:#12271d;
    --warn:#e3b341; --warn-soft:#2b2113;
    --bad:#ff8f8f; --bad-soft:#2d1719;
  }
}
html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--bg);color:var(--ink);font-family:var(--sans);
  font-size:16px;line-height:1.72;letter-spacing:-.005em}
.wrap{max-width:1180px;margin:0 auto;padding:32px 20px 96px;
  display:grid;grid-template-columns:220px minmax(0,1fr);gap:36px;align-items:start}
@media (max-width:900px){.wrap{grid-template-columns:1fr;gap:20px;padding-top:20px}}

/* 목차 */
nav.toc{position:sticky;top:24px;font-size:13.5px;line-height:1.5}
nav.toc .toc-h{font-size:11px;letter-spacing:.12em;text-transform:uppercase;
  color:var(--dim);margin:0 0 10px;font-weight:700}
nav.toc a{display:block;padding:6px 10px;border-radius:7px;color:var(--dim);
  text-decoration:none;border-left:2px solid transparent}
nav.toc a:hover{background:var(--card);color:var(--ink)}
nav.toc a.defense{border-left-color:var(--warn)}
nav.toc a.discard{border-left-color:var(--bad)}
@media (max-width:900px){nav.toc{position:static;
  background:var(--card);border:1px solid var(--line);border-radius:12px;padding:14px}}
@media print{nav.toc{display:none}}

main{min-width:0}
h1{font-size:31px;line-height:1.3;margin:0 0 14px;letter-spacing:-.02em}
h2{font-size:21px;margin:0 0 16px;letter-spacing:-.015em;
  padding-bottom:10px;border-bottom:1px solid var(--line)}
h3{font-size:17.5px;margin:26px 0 12px;letter-spacing:-.01em}
h4{font-size:15.5px;margin:20px 0 10px;color:var(--dim)}
p{margin:0 0 14px}
a{color:var(--accent)}
a.url{font-family:var(--mono);font-size:.86em;word-break:break-all}
code{font-family:var(--mono);font-size:.87em;background:var(--accent-soft);
  padding:.12em .4em;border-radius:5px}
hr{border:0;border-top:1px dashed var(--line);margin:26px 0}
ul,ol{margin:0 0 14px;padding-left:22px}
li{margin:5px 0}
strong{font-weight:700}

/* 섹션 카드 */
section{background:var(--card);border:1px solid var(--line);border-radius:14px;
  padding:22px 24px;margin:0 0 18px}
@media (max-width:600px){section{padding:18px 16px;border-radius:12px}}
section.defense{border-left:4px solid var(--warn)}
section.discard{border-left:4px solid var(--bad)}
section.trend,section.notice{background:var(--accent-soft);border-color:transparent}
section.checklist{font-size:14.5px;color:var(--dim)}
section.review{border-left:4px solid var(--bad)}
nav.toc a.review{border-left-color:var(--bad)}
.review-item{margin:14px 0;padding:12px 14px;border-radius:8px;background:var(--bad-soft)}
.review-item.mid{background:var(--warn-soft)}
.review-item.low{background:transparent;border:1px solid var(--line)}
.review-item p{margin:6px 0}
.review-loc{font-style:italic}

/* 부제 칩 */
.chips{display:flex;flex-wrap:wrap;gap:7px;margin:0 0 26px}
.chip{background:var(--card);border:1px solid var(--line);border-radius:999px;
  padding:5px 13px;font-size:13px;color:var(--dim)}

/* 요약 타일 */
.tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));
  gap:12px;margin:0 0 18px}
.tile{background:var(--bg);border:1px solid var(--line);border-radius:12px;
  padding:16px 14px;text-align:center}
.tile-v{font-size:29px;font-weight:750;line-height:1.15;font-variant-numeric:tabular-nums}
.tile-k{font-size:12.5px;color:var(--dim);margin-top:3px}
.tile.okish .tile-v{color:var(--ok)}
.tile.warnish .tile-v{color:var(--warn)}

/* 표 */
.tw{overflow-x:auto;margin:0 0 16px;-webkit-overflow-scrolling:touch}
table{border-collapse:collapse;width:100%;font-size:14.5px}
th,td{text-align:left;padding:9px 12px;border-bottom:1px solid var(--line);
  vertical-align:top}
thead th{font-size:12.5px;color:var(--dim);font-weight:700;white-space:nowrap;
  border-bottom:1.5px solid var(--line)}
tbody tr:last-child td,tbody tr:last-child th{border-bottom:0}
table.spec{margin:0 0 16px;background:var(--bg);border:1px solid var(--line);
  border-radius:10px;overflow:hidden}
table.spec th{width:132px;color:var(--dim);font-weight:600;font-size:13.5px;
  white-space:nowrap;background:transparent}

/* 초록 원문 */
figure.abstract{margin:0 0 16px;border:1px solid var(--line);border-radius:10px;
  overflow:hidden;background:var(--bg)}
figure.abstract figcaption{font-size:11px;letter-spacing:.1em;text-transform:uppercase;
  color:var(--dim);padding:8px 14px;border-bottom:1px solid var(--line);font-weight:700}
figure.abstract blockquote{margin:0;padding:13px 16px;font-family:var(--mono);
  font-size:13px;line-height:1.65;color:var(--dim)}
blockquote.note{margin:0 0 16px;padding:12px 16px;border-left:3px solid var(--line);
  background:var(--bg);border-radius:0 8px 8px 0;color:var(--dim);font-size:14.5px}

/* 배지 */
.badge{display:inline-block;font-size:12px;font-weight:700;padding:2px 9px;
  border-radius:999px;white-space:nowrap;line-height:1.6}
.badge.ok{background:var(--ok-soft);color:var(--ok)}
.badge.warn{background:var(--warn-soft);color:var(--warn)}
.badge.used{background:var(--accent-soft);color:var(--accent)}
.badge.label{background:var(--bg);color:var(--dim);border:1px solid var(--line)}
.warn-mark{color:var(--warn);font-weight:700}
a.pmid{font-family:var(--mono);font-size:.87em;text-decoration:none;
  background:var(--accent-soft);padding:.1em .45em;border-radius:5px;white-space:nowrap}

/* 후킹 카드 */
ol.hooks{list-style:none;padding:0;margin:0 0 16px;display:grid;gap:8px;counter-reset:h}
li.hook{counter-increment:h;display:flex;align-items:center;gap:12px;
  background:var(--bg);border:1px solid var(--line);border-radius:10px;padding:11px 14px}
li.hook::before{content:counter(h);flex:0 0 22px;height:22px;border-radius:50%;
  background:var(--accent);color:#fff;font-size:12px;font-weight:700;
  display:grid;place-items:center}
.hook-t{flex:1;font-size:15.5px;font-weight:600}
button.copy{flex:0 0 auto;border:1px solid var(--line);background:var(--card);
  color:var(--dim);font-family:inherit;font-size:12px;padding:5px 11px;
  border-radius:7px;cursor:pointer}
button.copy:hover{border-color:var(--accent);color:var(--accent)}
button.copy.done{background:var(--ok-soft);color:var(--ok);border-color:transparent}
@media print{button.copy{display:none}}

footer.meta{margin-top:26px;padding-top:16px;border-top:1px solid var(--line);
  font-size:12.5px;color:var(--dim)}
@media print{
  body{background:#fff;font-size:11pt}
  .wrap{display:block;max-width:none;padding:0}
  section{break-inside:avoid;border-radius:0;border:0;border-top:1px solid #ccc;
    padding:10px 0;margin:0}
  h2{break-after:avoid}
}
"""

JS = """
document.addEventListener('click',function(e){
  var b=e.target.closest('button.copy'); if(!b) return;
  var t=b.getAttribute('data-text')||'';
  var done=function(){b.textContent='복사됨';b.classList.add('done');
    setTimeout(function(){b.textContent='복사';b.classList.remove('done')},1400)};
  if(navigator.clipboard&&navigator.clipboard.writeText){
    navigator.clipboard.writeText(t).then(done,function(){})
  }else{
    var ta=document.createElement('textarea');ta.value=t;document.body.appendChild(ta);
    ta.select();try{document.execCommand('copy');done()}catch(_){}
    document.body.removeChild(ta)
  }
});
"""


def render_audit_banner(path):
    """숫자 대조에서 출처를 못 찾은 숫자가 남아 있으면 맨 위 경고 상자."""
    try:
        with open(path, encoding="utf-8") as f:
            errors = json.load(f).get("오류") or []
    except (OSError, json.JSONDecodeError) as e:
        die(f"숫자 대조 파일을 읽을 수 없습니다: {path} ({e})")
    if not errors:
        return ""
    items = "".join(
        f"<li>{html.escape(str(e.get('줄')))}행 「<strong>{html.escape(str(e.get('숫자')))}</strong>」 — "
        f"{html.escape(str(e.get('이유', '출처에 없음')))} · {html.escape(str(e.get('문맥', ''))[:80])}</li>"
        for e in errors)
    return ('<section class="review audit"><h2>출처를 못 찾은 숫자 '
            f'{len(errors)}개</h2><p><strong>아래 숫자는 원문을 확인하기 전에 쓰지 마십시오.</strong> '
            '숫자 대조에서 검증된 인용문·초록·제품 표시 어디에서도 찾지 못했습니다.</p>'
            f"<ul>{items}</ul></section>\n")


SEVERITY_CLASS = {"높음": "", "중간": "mid", "낮음": "low"}
SEVERITY_ORDER = {"높음": 0, "중간": 1, "낮음": 2}


def render_review(path):
    """P7 검토 파일 → (목차 항목, 절 HTML)."""
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        die(f"검토 파일을 읽을 수 없습니다: {path} ({e})")

    items = sorted(data.get("지적") or [], key=lambda x: SEVERITY_ORDER.get(x.get("심각도"), 3))
    counts = {k: sum(1 for x in items if x.get("심각도") == k) for k in SEVERITY_ORDER}
    head = " · ".join(f"{k} {v}건" for k, v in counts.items())
    out = ['<section id="review" class="review">',
           f"<h2>검토 메모 — {html.escape(str(data.get('판정', '')))}</h2>",
           "<p><strong>AI 검토 메모입니다. 사실 확인이 아닙니다.</strong> 원고 문장을 초록·트렌드·제품 표시와 "
           "대조해 어긋나 보이는 곳을 표시한 것입니다. 맞는 지적인지는 발행 전에 직접 판단하십시오.</p>",
           f"<p>{html.escape(head)}</p>"]
    if not items:
        out.append("<p>지적 없음.</p>")
    for it in items:
        cls = SEVERITY_CLASS.get(it.get("심각도"), "low")
        pmid = f" · PMID {it['PMID']}" if it.get("PMID") else ""
        out.append(
            f'<div class="review-item {cls}">'
            f'<p><span class="badge warn">{html.escape(str(it.get("심각도")))}</span> '
            f'<strong>{html.escape(str(it.get("유형")))}</strong>{inline(pmid)}</p>'
            f'<p class="review-loc">「{html.escape(str(it.get("위치")))}」</p>'
            f'<p>{inline(str(it.get("근거", "")))}</p>'
            f'<p><strong>제안</strong> — {inline(str(it.get("제안", "")))}</p>'
            "</div>"
        )
    out.append("</section>")
    return ("review", "검토 메모", "review"), "\n".join(out)


def page(title, toc, body, src_name):
    nav = ""
    if toc:
        links = "".join(
            f'<a href="#{s}" class="{tone}">{html.escape(label)}</a>'
            for s, label, tone in toc
        )
        nav = f'<nav class="toc"><p class="toc-h">목차</p>{links}</nav>'
    else:
        nav = "<nav class=\"toc\"></nav>"

    return f"""<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(title)}</title>
<style>{CSS}</style>
</head>
<body>
<div class="wrap">
{nav}
<main>
{body}
<footer class="meta">
원본 마크다운: <code>{html.escape(src_name)}</code> ·
이 페이지는 <code>scripts/render_html.py</code> 가 생성했습니다 —
직접 고치면 다음 렌더에서 덮어써집니다.
</footer>
</main>
</div>
<script>{JS}</script>
</body>
</html>
"""


# ---------------------------------------------------------------------------


def main():
    args = sys.argv[1:]
    opts = {}
    for flag in ("--review", "--audit"):
        for j, x in enumerate(args):
            if x.startswith(flag + "="):
                opts[flag] = x.split("=", 1)[1]
                del args[j]
                break
            if x == flag:
                if j + 1 >= len(args):
                    die(f"{flag} 뒤에 파일 경로가 없습니다")
                opts[flag] = args[j + 1]
                del args[j:j + 2]
                break
    review_path, audit_path = opts.get("--review"), opts.get("--audit")
    if len(args) < 2:
        print(
            f"사용법: python3 {sys.argv[0]} <원고.md> <출력.html> "
            f"[점수파일-검증됨.json] [--review 검토.json] [--audit 숫자대조.json]",
            file=sys.stderr,
        )
        sys.exit(2)

    md_path, out_path = args[0], args[1]
    scored_path = args[2] if len(args) > 2 else None

    try:
        with open(md_path, encoding="utf-8") as f:
            md_lines = f.read().splitlines()
    except OSError as e:
        die(f"브리핑을 읽을 수 없습니다: {md_path} ({e})")

    if not md_lines:
        die(f"브리핑이 비어 있습니다: {md_path}")

    # 요약 숫자 교차검증 — 어긋나면 HTML을 만들지 않는다
    if scored_path:
        mismatches = crosscheck_summary(md_lines, scored_path)
        if mismatches:
            print(
                f"[요약 불일치] {md_path} 의 요약표가 "
                f"{os.path.basename(scored_path)} 의 `요약` 필드와 다릅니다:",
                file=sys.stderr,
            )
            for m in mismatches:
                print(f"  - {m}", file=sys.stderr)
            print(
                "\nbrief-writer 가 숫자를 직접 셌거나, 원고를 쓴 뒤 점수 파일이 바뀌었습니다.\n"
                "파일을 손으로 고치지 말고 brief-writer 를 다시 불러 `요약` 필드를 그대로 옮기게 하십시오.",
                file=sys.stderr,
            )
            sys.exit(3)

    blocks = parse_blocks(md_lines)
    body, title, toc = render(blocks)
    if review_path:
        entry, section = render_review(review_path)
        toc.append(entry)
        body += "\n" + section
    if audit_path:
        body = render_audit_banner(audit_path) + body
    # 브라우저 탭 제목에 날짜를 붙인다 — 탭 여러 개를 열어도 구분되게 (파일 이름이 날짜로 시작할 때)
    m = re.match(r"(\d{4}-\d{2}-\d{2})_", os.path.basename(md_path))
    if m and m.group(1) not in title:
        title = f"{title} · {m.group(1)}"
    out = page(title, toc, body, os.path.basename(md_path))

    try:
        tmp = f"{out_path}.tmp-{os.getpid()}"
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(out)
        os.replace(tmp, out_path)
    except OSError as e:
        die(f"출력을 쓸 수 없습니다: {out_path} ({e})")

    kb = len(out.encode("utf-8")) / 1024
    print(f"HTML 생성: {out_path} ({kb:.0f} KB, 섹션 {len(toc)}개)")
    sys.exit(0)


if __name__ == "__main__":
    main()
