pubmed-workshop-agent-teams — 약사 스터디 실습 폴더 (에이전트 팀 버전)
========================================

이 폴더를 Claude Code(데스크톱 앱 또는 터미널)로 여세요.

들어 있는 것 — 전부 완성본입니다. 만들 것은 없습니다.
- .claude/agents/abstract-miner.md : 서브에이전트 1호 (초록에서 숫자 오려내기)
- .claude/agents/evidence-scout.md : 서브에이전트 2호 (논문 지형 정찰)
- .claude/commands/진행.md         : 커맨드 (두 에이전트를 팀으로 돌리는 진입점)
- .claude/skills/pubmed-evidence/SKILL.md          : 스킬 (전체 진행 순서)
- .claude/skills/pubmed-evidence/references/normalize.md : 용어 사전
- scripts/verify_evidence.py      : 검사기 (실습 3단계에서 돌립니다)
- scripts/test_verify_evidence.py : 검사기의 시험지
- .claude/settings.json           : NCBI API 키를 넣는 곳 (실습 0단계)
  * Mac에서 .claude 폴더는 숨김 처리라 안 보일 수 있습니다. 정상입니다.

실습에서 여러분이 하는 일은 **이것들을 읽고 호출하는 것**입니다.
지시문을 직접 만들지 않습니다 — 대신 안을 열어 무엇이 적혀 있는지 봅니다.

실습 안내 문서(pubmed-evidence-workshop.html)를 열고 STEP 0부터 따라가세요.
