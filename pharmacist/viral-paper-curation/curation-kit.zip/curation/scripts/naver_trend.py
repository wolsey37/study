#!/usr/bin/env python3
"""
P1 검색량 추이 — 네이버 데이터랩 통합검색어 트렌드로 주제별 검색량을 잰다.

# 왜 필요한가

`trend-scout` 는 웹 검색 결과를 읽고 「요즘 이게 화제인 것 같다」를
판단한다. 그건 기사·블로그에 무엇이 실렸는가이지, **사람들이 실제로
무엇을 검색하는가**가 아니다. 원 요청은 「SNS 또는 네이버 검색어로
그 시기에 바이럴되는 이슈」였다. 이 스크립트가 그 검색어 쪽을 채운다.

# 무엇을 재는가

`과정/트렌드.json` 의 `주제후보[].검색키워드` 를 주제별 검색어 묶음으로
보내, 최근 12주 주간 추이를 받는다. 데이터랩의 주는 월요일에 시작하므로 **끝난 주까지만**
센다 — 오늘이 든 주를 넣으면 며칠치만 잡혀 모든 주제가 「하락」으로 보인다. 주제마다 두 값을 낸다.

- **변화배수** = 최근 4주 평균 ÷ 직전 8주 평균. 1.3배 이상이면 상승
- **성분대비** = 그 주제 검색량 ÷ 성분명 자체 검색량. 주제끼리의 크기 비교용

데이터랩의 `ratio` 는 **한 요청 안에서 가장 큰 값을 100으로 둔 상댓값**
이다. 한 요청에 묶음이 5개까지라, 주제가 5개를 넘으면 요청이 나뉘고
요청끼리는 눈금이 다르다. 그래서 **요청마다 성분명 묶음을 기준으로
끼워 넣고**, 주제 검색량을 그 기준으로 나눈다. 요청이 나뉘어도
「성분 전체 검색의 몇 %」라는 같은 눈금이 된다.

`--gender` · `--ages` 를 주면 **그 오디언스의 검색만** 센다. 계정 오디언스가
30-40대 여성이면 그 사람들이 무엇을 검색하는지를 보는 것이다.

# 키

환경변수 `NAVER_CLIENT_ID` · `NAVER_CLIENT_SECRET`. 받는 곳이 두 군데다.

| 받는 곳 | 주소 · 인증 헤더 | 기존 키 |
|---|---|---|
| **NAVER API HUB** (네이버 클라우드 플랫폼) — 새 키는 여기서만 받는다 | `naverapihub.apigw.ntruss.com/search-trend/v1/search` · `X-NCP-APIGW-API-KEY-ID` / `-KEY` | — |
| 네이버 개발자센터 (developers.naver.com) — 2026-07-31 신규 신청 종료 | `openapi.naver.com/v1/datalab/search` · `X-Naver-Client-Id` / `-Secret` | 2027-06-30 호출 차단 |

**어느 쪽 키든 같은 두 칸에 넣는다.** API HUB 주소로 먼저 부르고, 인증에 실패하면(401·403)
개발자센터 주소로 한 번 더 부른다. 요청 본문은 둘이 같다. 둘 다 실패하면 두 곳의 응답을 함께
적는다. `NAVER_API=hub` 또는 `NAVER_API=developers` 로 한쪽만 쓰게 할 수 있다.

API HUB 는 검색어 트렌드를 기본 3만 건까지 무료로 준다 (한 번 돌리는 데 2~3건).

**키가 없어도 파이프라인은 멈추지 않는다.** 검색량 칸이 비어 있다는
안내만 담아 파일을 쓰고 exit 0. 검색량은 주제를 고를 때의 참고
자료이지, 없으면 논문을 못 찾는 재료가 아니다.

# 사용법

    python3 naver_trend.py <트렌드파일> <출력파일> [--gender f] [--ages 5,6,7,8]

exit 0 성공 또는 키 없음 / 2 입력 오류 / 4 API 호출 실패 (파일은 안내와 함께 씀)
"""

import argparse
import datetime as dt
import http.client
import json
import os
import sys
import urllib.error
import urllib.request

ENDPOINTS = {
    # NAVER API HUB — 새 키는 여기서만 발급된다
    "hub": ("https://naverapihub.apigw.ntruss.com/search-trend/v1/search",
            "X-NCP-APIGW-API-KEY-ID", "X-NCP-APIGW-API-KEY"),
    # 네이버 개발자센터 — 2026-07-31 이전에 받은 키. 2027-06-30 에 호출이 막힌다
    "developers": ("https://openapi.naver.com/v1/datalab/search",
                   "X-Naver-Client-Id", "X-Naver-Client-Secret"),
}
_working = []   # 한 번 통한 주소는 이번 실행 내내 쓴다
MAX_GROUPS = 5          # 데이터랩 한 요청당 묶음 상한
MAX_KEYWORDS = 20       # 묶음당 검색어 상한
RECENT_WEEKS = 4
BASE_WEEKS = 8

# 판정 기준. 검색량이 아주 작으면 배수가 크게 흔들리므로 따로 표시한다.
UP, DOWN = 1.3, 0.77
TOO_SMALL = 0.5         # 최근 4주 평균 ratio 가 이보다 작으면 「검색량 적음」


def die(msg, code=2):
    print(f"[오류] {msg}", file=sys.stderr)
    sys.exit(code)


class ApiError(Exception):
    def __init__(self, msg, code=None):
        super().__init__(msg)
        self.code = code


def write(path, data):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = f"{path}.tmp-{os.getpid()}"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def load_groups(trend_path):
    try:
        with open(trend_path, encoding="utf-8") as f:
            trend = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        die(f"트렌드 파일을 읽을 수 없습니다: {trend_path} ({e})")

    ingredient = trend.get("성분")
    if not ingredient:
        die(f"{trend_path} 에 `성분` 이 없습니다")

    groups = {}
    for c in trend.get("주제후보", []):
        name = c.get("주제")
        raw = c.get("검색키워드") or []
        raw = [raw] if isinstance(raw, str) else raw
        kws = [k.strip() for k in raw if isinstance(k, str) and k.strip()]
        # 성분명만 덩그러니 있는 검색어는 기준 묶음과 같아서 뺀다
        kws = [k for k in kws if k != ingredient]
        if name and kws:
            groups[name] = kws[:MAX_KEYWORDS]
    return ingredient, groups


def period_range(today):
    """끝난 주 12개 — 월요일 시작, 지난 일요일 끝. 오늘이 일요일이어도 오늘은 아직 안 끝났다."""
    end = today - dt.timedelta(days=today.weekday() + 1)
    start = end - dt.timedelta(weeks=RECENT_WEEKS + BASE_WEEKS) + dt.timedelta(days=1)
    return start, end


def _post(name, body, cid, secret):
    url, id_header, secret_header = ENDPOINTS[name]
    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode("utf-8"),
        headers={id_header: cid, secret_header: secret, "Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.load(r)


def call_api(body, cid, secret):
    """API HUB 로 먼저 부르고, 인증 실패면 개발자센터로. 키가 어디서 발급됐는지 몰라도 된다."""
    forced = (os.environ.get("NAVER_API") or "").strip().lower()
    order = _working or ([forced] if forced in ENDPOINTS else ["hub", "developers"])
    failures = []
    for name in order:
        label = "NAVER API HUB" if name == "hub" else "네이버 개발자센터"
        try:
            data = _post(name, body, cid, secret)
            if not _working:
                _working.append(name)
                print(f"[안내] 데이터랩 호출 경로: {label}")
            return data
        except urllib.error.HTTPError as e:
            detail = e.read().decode("utf-8", "ignore")[:200]
            failures.append((e.code, f"{label} HTTP {e.code} {detail}".strip()))
            if e.code not in (401, 403) or _working:
                break
        except (OSError, http.client.HTTPException, json.JSONDecodeError) as e:
            failures.append((None, f"{label} {e}"))
            break
    # 새 키는 API HUB 에서만 나오므로 HUB 쪽 응답을 앞에 둔다
    raise ApiError(" / ".join(msg for _, msg in failures), failures[0][0] if failures else None)


def window_means(points, start, end):
    """주간 ratio 목록에서 (최근 4주 평균, 직전 8주 평균).

    데이터랩은 검색량이 0인 주를 응답에서 빼기도 한다. 빠진 주를 평균에서
    제외하면 검색이 드문 주제가 부풀려지므로, **기간 길이로 나눠**
    빠진 주를 0으로 친다.
    """
    cut = end - dt.timedelta(weeks=RECENT_WEEKS) + dt.timedelta(days=1)
    recent, base = 0.0, 0.0
    for p in points:
        d = dt.date.fromisoformat(p["period"])
        v = float(p["ratio"])
        if d >= cut:
            recent += v
        elif d >= start:
            base += v
    return recent / RECENT_WEEKS, base / BASE_WEEKS


def judge(recent, base):
    if recent < TOO_SMALL and base < TOO_SMALL:
        return None, "검색량 적음"
    if base < TOO_SMALL:
        return None, "급등(직전 검색 거의 없음)"
    mult = recent / base
    if mult >= UP:
        return round(mult, 2), "상승"
    if mult <= DOWN:
        return round(mult, 2), "하락"
    return round(mult, 2), "보합"


def measure(ingredient, groups, start, end, gender, ages, cid, secret):
    """주제별 결과 dict. 요청을 나눠도 성분 기준 묶음으로 눈금을 맞춘다."""
    names = list(groups)
    per_request = MAX_GROUPS - 1          # 한 자리는 기준 묶음
    out = {}
    for i in range(0, len(names), per_request):
        chunk = names[i:i + per_request]
        body = {
            "startDate": start.isoformat(),
            "endDate": end.isoformat(),
            "timeUnit": "week",
            "keywordGroups": [{"groupName": "__기준__", "keywords": [ingredient]}]
                             + [{"groupName": n, "keywords": groups[n]} for n in chunk],
        }
        if gender:
            body["gender"] = gender
        if ages:
            body["ages"] = ages

        res = call_api(body, cid, secret)
        by_title = {r["title"]: r.get("data", []) for r in res.get("results", [])}

        anchor_recent, anchor_base = window_means(by_title.get("__기준__", []), start, end)
        anchor = (anchor_recent * RECENT_WEEKS + anchor_base * BASE_WEEKS) / (RECENT_WEEKS + BASE_WEEKS)

        for n in chunk:
            recent, base = window_means(by_title.get(n, []), start, end)
            mult, verdict = judge(recent, base)
            level = (recent * RECENT_WEEKS + base * BASE_WEEKS) / (RECENT_WEEKS + BASE_WEEKS)
            out[n] = {
                "검색키워드": groups[n],
                "최근4주": round(recent, 2),
                "직전8주": round(base, 2),
                "변화배수": mult,
                "성분대비": round(level / anchor, 3) if anchor > 0 else None,
                "판정": verdict,
            }
    return out


def main():
    ap = argparse.ArgumentParser(description="네이버 데이터랩으로 주제별 검색량 추이를 잰다")
    ap.add_argument("trend_file")
    ap.add_argument("out_file")
    ap.add_argument("--gender", choices=["m", "f"])
    ap.add_argument("--ages", help="데이터랩 연령 코드, 쉼표로. 예: 5,6,7,8 (30~49세)")
    ap.add_argument("--today", help="기준일 YYYY-MM-DD (시험용)")
    a = ap.parse_args()

    ages = [x.strip() for x in a.ages.split(",")] if a.ages else None
    if ages and not all(x.isdigit() and 1 <= int(x) <= 11 for x in ages):
        die("--ages 는 1~11 사이 숫자를 쉼표로 이은 것이어야 합니다")

    ingredient, groups = load_groups(a.trend_file)
    today = dt.date.fromisoformat(a.today) if a.today else dt.date.today()
    start, end = period_range(today)

    result = {
        "성분": ingredient,
        "기간": {"시작": start.isoformat(), "끝": end.isoformat(), "단위": "주"},
        "필터": {"성별": a.gender, "연령코드": ages},
        "기준어": ingredient,
        "주제": {},
        "안내": None,
    }

    if not groups:
        result["안내"] = "트렌드 파일에 `검색키워드` 가 붙은 주제후보가 없어 검색량을 재지 않았습니다"
        write(a.out_file, result)
        print(f"[안내] {result['안내']}")
        sys.exit(0)

    cid = os.environ.get("NAVER_CLIENT_ID")
    secret = os.environ.get("NAVER_CLIENT_SECRET")
    if not cid or not secret:
        result["안내"] = "NAVER_CLIENT_ID·NAVER_CLIENT_SECRET 이 없어 검색량 없이 진행합니다"
        write(a.out_file, result)
        print(f"[안내] {result['안내']}")
        sys.exit(0)

    try:
        result["주제"] = measure(ingredient, groups, start, end, a.gender, ages, cid, secret)
    except ApiError as e:
        result["안내"] = f"데이터랩 호출 실패 — 검색량 없이 진행합니다. {e}"
        write(a.out_file, result)
        print(f"[오류] {result['안내']}", file=sys.stderr)
        sys.exit(4)
    except (KeyError, TypeError, ValueError) as e:
        result["안내"] = f"데이터랩 응답을 읽지 못했습니다 ({e!r}) — 검색량 없이 진행합니다"
        write(a.out_file, result)
        print(f"[오류] {result['안내']}", file=sys.stderr)
        sys.exit(4)

    write(a.out_file, result)
    for n, v in result["주제"].items():
        mult = f"{v['변화배수']}배" if v["변화배수"] is not None else "-"
        share = f"{v['성분대비']:.1%}" if v["성분대비"] is not None else "-"
        print(f"  {n:<14} {v['판정']:<8} 변화 {mult:<7} 성분대비 {share}")
    print(f"→ {a.out_file}")
    sys.exit(0)


if __name__ == "__main__":
    main()
