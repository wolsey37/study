#!/usr/bin/env python3
"""
실행 폴더 — 큐레이션 한 번에 폴더 하나를 만들고, 전체 목록을 만든다.

# 왜 폴더인가

파일 이름에 성분을 붙여 구분하면, 같은 성분의 다른 제품을 같은 날 돌릴 때
서로 덮어쓴다. 실행마다 폴더가 따로면 이름이 겹칠 일이 없다. 공구를 매주 돌리면 폴더가
빨리 쌓이므로 **달별 폴더** 아래에 둔다. 성분·제품으로 찾는 것은 `목록.html` 의 필터가 한다.

    큐레이션/2026-09/2026-09-28_알티지-오메가3-1200/
    ├── 실행.json          입력 · 제품 · 성분 · 주제 · 계정 · 키 상태
    ├── 2026-09-28_알티지-오메가3-1200.md     원고
    ├── 2026-09-28_알티지-오메가3-1200.html   최종 결과 (폴더 밖에서도 알아보게 폴더 이름을 파일 이름으로)
    └── 과정/              지워도 되는 것 (트렌드 · 후보 · 점수 · 검토 …)

# 사용법

    python3 runs.py new "<입력>" [--date YYYY-MM-DD]   # 폴더를 만들고 경로를 출력
    python3 runs.py set <실행폴더> <키> <값>            # 실행.json 한 칸을 채움 (값은 JSON 또는 글자)
    python3 runs.py profile                           # 계정 이름 (계정/프로필.md 의 `계정:`)
    python3 runs.py keys [<실행폴더>]                  # API 키 있음/없음 (값은 출력하지 않음). 폴더를 주면 실행.json 에도 적음
    python3 runs.py archive-review <실행폴더>          # 첫 검토를 과정/검토.1차.json 으로 옮김 (고쳐 쓰기 전)
    python3 runs.py index                             # 큐레이션/목록.html 을 다시 만듦

exit 0 성공 / 2 입력 오류 / 3 이미 한 번 고쳐 썼음 (archive-review)
"""

import argparse
import datetime as dt
import glob
import html
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RUNS = os.path.join(ROOT, "큐레이션")
PROFILE = os.path.join(ROOT, "계정", "프로필.md")   # 계정은 하나 — 이 파일 하나로 관리한다
MANIFEST = "실행.json"
WORK = "과정"

SETTABLE = {"성분", "제품", "주력주제", "부차주제", "주제출처", "키", "상태", "메모"}


def die(msg, code=2):
    print(f"[오류] {msg}", file=sys.stderr)
    sys.exit(code)


def write_json(path, data):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = f"{path}.tmp-{os.getpid()}"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def read_json(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return None


def slug(text):
    s = re.sub(r"[^\w가-힣]+", "-", text.strip())
    return re.sub(r"-{2,}", "-", s).strip("-") or "실행"


def profile_name():
    """계정/프로필.md 의 `계정:` 값. 파일이 없거나 값이 비었으면 None."""
    try:
        text = open(PROFILE, encoding="utf-8").read()
    except OSError:
        return None
    # [ \t] — 값이 빈 줄에서 다음 줄로 넘어가 읽지 않게 한다
    m = re.search(r"^계정:[ \t]*(.*?)[ \t]*(?:#.*)?$", text, re.M)
    name = m.group(1).strip().strip("'\"").strip() if m else ""
    return None if name.lower() in ("", "null", "~") else name


# ---------------------------------------------------------------------------


def cmd_new(a):
    date = a.date or dt.date.today().isoformat()
    try:
        date = dt.date.fromisoformat(date).isoformat()
    except ValueError:
        die(f"날짜가 아닙니다: {date} — YYYY-MM-DD")
    base = os.path.join(RUNS, date[:7], f"{date}_{slug(a.input)}")
    path, n = base, 2
    while os.path.exists(path):          # 같은 날 같은 입력을 또 돌리면 -2, -3 …
        path, n = f"{base}-{n}", n + 1
    os.makedirs(os.path.join(path, WORK))
    write_json(os.path.join(path, MANIFEST), {
        "입력": a.input,
        "날짜": date,
        "성분": None,
        "제품": None,
        "계정": profile_name(),
        "주력주제": None,
        "부차주제": [],
        "키": {},
        "상태": "진행중",
    })
    print(os.path.relpath(path, ROOT))


def cmd_set(a):
    path = os.path.join(a.run, MANIFEST)
    data = read_json(path)
    if data is None:
        die(f"실행 폴더가 아닙니다 (실행.json 없음): {a.run}")
    if a.key not in SETTABLE:
        die(f"바꿀 수 없는 칸입니다: {a.key} — {sorted(SETTABLE)}")
    try:
        value = json.loads(a.value)
    except json.JSONDecodeError:
        value = a.value
    if a.key == "부차주제" and isinstance(value, str):
        value = [value]                      # 한 개만 주면 목록으로 감싼다 (「중성지방」 → ["중성지방"])
    expected = {"부차주제": list, "제품": (dict, type(None)), "키": dict}.get(a.key)
    if expected and not isinstance(value, expected):
        die(f"{a.key} 값의 형식이 틀립니다: {a.value} — 예: " +
            {"부차주제": "'[\"중성지방\"]'",
             "제품": "'{\"신고번호\":\"…\",\"제품명\":\"…\",\"제조사\":\"…\"}'", "키": "'{\"NCBI\":\"있음\"}'"}[a.key])
    if a.key in ("성분", "주력주제", "상태") and not isinstance(value, (str, type(None))):
        value = str(value)
    data[a.key] = value
    write_json(path, data)
    print(f"{a.key} = {json.dumps(value, ensure_ascii=False)}")


def cmd_profile(_):
    name = profile_name()
    if not name:
        die("계정/프로필.md 가 없거나 `계정:` 이 비어 있습니다 — 그 파일에 계정 이름부터 적으십시오")
    print(name)


KEYS = {"NCBI": ["NCBI_API_KEY"], "네이버": ["NAVER_CLIENT_ID", "NAVER_CLIENT_SECRET"],
        "식약처": ["FOODSAFETY_API_KEY"]}


def cmd_keys(a):
    """키가 이 세션에 들어와 있는지. 값은 어디에도 출력하지 않는다."""
    status = {k: "있음" if all(os.environ.get(v, "").strip() for v in names) else "없음"
              for k, names in KEYS.items()}
    try:
        with open(os.path.join(ROOT, ".claude", "settings.local.json"), encoding="utf-8") as f:
            saved = (json.load(f) or {}).get("env") or {}
    except (OSError, json.JSONDecodeError, AttributeError):
        saved = {}
    for k, names in KEYS.items():
        if status[k] == "없음" and all(str(saved.get(v) or "").strip() for v in names):
            print(f"[안내] {k} 키가 settings.local.json 에는 있지만 이 세션에는 아직 없습니다 — "
                  "Claude Code 를 종료(/exit)하고 이 폴더에서 다시 여십시오", file=sys.stderr)
    print(json.dumps(status, ensure_ascii=False))
    if a.run:
        path = os.path.join(a.run, MANIFEST)
        data = read_json(path)
        if not isinstance(data, dict):
            die(f"실행 폴더가 아닙니다 (실행.json 없음): {a.run}")
        data["키"] = status
        write_json(path, data)


def cmd_archive_review(a):
    """고쳐 쓰기 전에 첫 검토를 남긴다. 고쳐 쓰기는 실행마다 한 번이다."""
    work = os.path.join(a.run, WORK)
    src, dst = os.path.join(work, "검토.json"), os.path.join(work, "검토.1차.json")
    if os.path.exists(dst):
        die("이미 한 번 고쳐 썼습니다 (과정/검토.1차.json 있음) — 더 고쳐 쓰지 않고 지금 원고로 렌더합니다", 3)
    if not os.path.exists(src):
        die(f"검토 파일이 없습니다: {src}")
    os.replace(src, dst)
    print(os.path.relpath(dst, ROOT))


# ---------------------------------------------------------------------------
# 목록
# ---------------------------------------------------------------------------


def _text(x):
    return x if isinstance(x, str) else None


def run_rows():
    """실행 폴더마다 한 줄. 실행.json 이 깨졌거나 옛 형식이어도 목록은 만든다 — 빈칸으로 둔다."""
    rows = []
    for mpath in sorted(glob.glob(os.path.join(RUNS, "*", "*", MANIFEST)), reverse=True):
        run = os.path.dirname(mpath)
        m = read_json(mpath)
        m = m if isinstance(m, dict) else {}
        name = os.path.basename(run)
        html_file = os.path.join(run, f"{name}.html")
        sub = m.get("부차주제")
        sub = [sub] if isinstance(sub, str) else [t for t in (sub or []) if isinstance(t, str)] \
            if isinstance(sub, list) else []
        summary = (read_json(os.path.join(run, WORK, "점수-검증됨.json")) or {})
        summary = summary.get("요약") if isinstance(summary, dict) else None
        review = read_json(os.path.join(run, WORK, "검토.json"))
        rows.append({
            "폴더": name,
            "날짜": _text(m.get("날짜")) or name[:10],
            "입력": _text(m.get("입력")),
            "제품": m.get("제품") if isinstance(m.get("제품"), dict) else None,
            "성분": _text(m.get("성분")),
            "주제": [t for t in [_text(m.get("주력주제"))] + sub if t],
            "계정": _text(m.get("계정")),
            "요약": summary if isinstance(summary, dict) else {},
            "검토": review if isinstance(review, dict) else None,
            "html": os.path.relpath(html_file, RUNS) if os.path.exists(html_file) else None,
            "상태": _text(m.get("상태")) or ("깨진 실행.json" if not m else None),
        })
    return rows


FILTER_JS = """
(function(){
  var rows=[].slice.call(document.querySelectorAll('tbody tr'));
  var sel=[].slice.call(document.querySelectorAll('[data-f]'));
  var q=document.getElementById('q'), n=document.getElementById('n');
  function apply(){
    var text=(q.value||'').trim().toLowerCase(), shown=0;
    rows.forEach(function(r){
      var ok=sel.every(function(s){return !s.value || r.dataset[s.dataset.f]===s.value;});
      if(ok && text) ok=r.textContent.toLowerCase().indexOf(text)>=0;
      r.hidden=!ok; if(ok) shown++;
    });
    n.textContent=shown+' / '+rows.length+'건';
  }
  sel.forEach(function(s){s.addEventListener('change',apply)});
  q.addEventListener('input',apply);
  document.getElementById('reset').addEventListener('click',function(){
    sel.forEach(function(s){s.value=''}); q.value=''; apply();
  });
  apply();
})();
"""

FILTERS = [("month", "달"), ("ingredient", "성분"), ("product", "제품")]


def cmd_index(_):
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from render_html import CSS

    rows = run_rows()
    esc = lambda x: html.escape("" if x is None else str(x))
    values = {k: set() for k, _ in FILTERS}
    body = []
    for r in rows:
        prod = r["제품"] or {}
        keys = {
            "month": (r["날짜"] or "")[:7],
            "ingredient": r["성분"] or "",
            "product": prod.get("제품명") or "",
        }
        for k, v in keys.items():
            if v:
                values[k].add(v)
        prod_txt = (f"{esc(prod.get('제품명'))}<br><small>{esc(prod.get('제조사'))}</small>"
                    if prod else "<small>성분명으로 실행</small>")
        topics = " · ".join(esc(t) for t in r["주제"] if t)
        s = r["요약"]
        weak = s.get("근거약함_포함")
        summary = f"{s.get('총_논문수', '-')}편 · 근거약함 {weak if weak is not None else '-'}"
        rv = r["검토"] if isinstance(r["검토"], dict) else None
        if rv is None:
            review = "-"
        else:
            items = rv.get("지적") if isinstance(rv.get("지적"), list) else []
            high = sum(1 for x in items if isinstance(x, dict) and x.get("심각도") == "높음")
            review = f"높음 {high}건 남음" if high else "높음 없음"
        link = (f'<a href="{esc(r["html"])}" target="_blank" rel="noopener noreferrer">열기</a>' if r["html"]
                else f"<small>{esc(r['상태'])}</small>")
        data = " ".join(f'data-{k}="{esc(v)}"' for k, v in keys.items())
        body.append(
            f"<tr {data}><td>{esc(r['날짜'])}</td><td>{esc(r['입력'])}</td><td>{prod_txt}</td>"
            f"<td>{esc(r['성분'])}</td><td>{topics}</td><td>{link}</td>"
            f"<td>{esc(summary)}</td><td>{esc(review)}</td></tr>"
        )
    selects = "".join(
        f'<label>{label} <select data-f="{k}"><option value="">전체</option>'
        + "".join(f'<option value="{esc(v)}">{esc(v)}</option>'
                  for v in sorted(values[k], reverse=(k == "month")))
        + "</select></label>"
        for k, label in FILTERS
    )
    filters = (f'<div class="filters">{selects}'
               f'<label>검색 <input id="q" type="search" placeholder="주제 · 입력 · 제조사"></label>'
               f'<button id="reset" type="button">초기화</button> <span id="n"></span></div>')
    table = ("<table><thead><tr><th>날짜</th><th>입력</th><th>제품</th><th>성분</th>"
             "<th>주제</th><th>결과</th><th>논문</th><th>검토</th></tr></thead><tbody>"
             + "".join(body) + "</tbody></table>") if body else "<p>아직 실행이 없습니다.</p>"
    runs = len({r["폴더"] for r in rows})
    out = f"""<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>큐레이션 목록</title>
<style>{CSS}
.list{{max-width:1100px;margin:0 auto;padding:24px 16px}}
.list table{{width:100%}}
.list td small{{color:var(--dim)}}
.filters{{display:flex;flex-wrap:wrap;gap:8px 14px;align-items:center;margin:14px 0}}
.filters select,.filters input,.filters button{{font:inherit;padding:4px 8px;border:1px solid var(--line);
  border-radius:6px;background:var(--card);color:var(--ink)}}
#n{{color:var(--dim)}}
</style>
</head>
<body>
<main class="list">
<h1>큐레이션 목록</h1>
<p>실행 {runs}번 · 결과 {sum(1 for r in rows if r['html'])}개.
이 페이지는 <code>scripts/runs.py index</code> 가 만듭니다 — 직접 고치면 다음에 덮어써집니다.</p>
{filters if body else ""}
<div class="tw">{table}</div>
</main>
<script>{FILTER_JS if body else ""}</script>
</body>
</html>
"""
    os.makedirs(RUNS, exist_ok=True)
    path = os.path.join(RUNS, "목록.html")
    tmp = f"{path}.tmp-{os.getpid()}"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(out)
    os.replace(tmp, path)
    print(f"목록: {os.path.relpath(path, ROOT)} (실행 {runs}번)")


def main():
    ap = argparse.ArgumentParser(description="큐레이션 실행 폴더")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("new")
    p.add_argument("input")
    p.add_argument("--date")
    p.set_defaults(fn=cmd_new)
    p = sub.add_parser("set")
    p.add_argument("run")
    p.add_argument("key")
    p.add_argument("value")
    p.set_defaults(fn=cmd_set)
    sub.add_parser("profile").set_defaults(fn=cmd_profile)
    p = sub.add_parser("keys")
    p.add_argument("run", nargs="?")
    p.set_defaults(fn=cmd_keys)
    p = sub.add_parser("archive-review")
    p.add_argument("run")
    p.set_defaults(fn=cmd_archive_review)
    sub.add_parser("index").set_defaults(fn=cmd_index)
    a = ap.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
