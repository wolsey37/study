#!/usr/bin/env python3
"""
성분사전 건강검진.

사전에 적힌 MeSH 주제어가 **지금도 유효한지** PubMed에 물어보고,
확인일이 오래된 항목을 알려준다.

# 왜 필요한가

사전은 만든 순간부터 낡기 시작한다. 바뀌는 것이 셋 있다.

1. **MeSH 자체가 매년 갱신된다.** 미국 국립의학도서관이 해마다
   용어를 추가·폐기·개명한다. 폐기된 용어로 검색하면 **에러가 나지
   않고 0건이 나온다.** 조용히 실패하므로 눈치채기 어렵다.
2. **지침과 고시가 개정된다.** 「2023년 6개 단체 권고」 같은 `주의`
   항목은 새 발표가 나오면 뒤집힌다.
3. **제외해야 할 유사 성분이 늘어난다.** 시장에 새 형태가 나온다.

1번은 이 스크립트가 기계로 잡는다. 2·3번은 사람이 봐야 하므로
`확인일` 이 오래된 항목을 골라 보여주는 것까지만 한다.

# 사용법

    python3 scripts/check_dictionary.py            # 전체 점검
    python3 scripts/check_dictionary.py 오메가3     # 한 성분만

`NCBI_API_KEY` 가 있으면 빠르고, 없으면 항목마다 1초씩 쉰다.

exit 0 모두 유효 / 1 확인 필요한 MeSH 있음 / 2 입력 오류 (사전에 없는 성분 포함) / 3 조회 실패로 판정 못 함
"""

import json
import os
import re
import sys
import time
import urllib.parse
import urllib.request
from datetime import date

EUTILS = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
DICT_DIR = os.path.join(os.path.dirname(__file__), "..", "사전")


def read_dictionary_text():
    """`사전/<분류>/<성분>.md` 를 전부 읽어 이어 붙인다.

    성분 하나가 파일 하나다. 파일마다 `## <성분명>` + ```yaml 블록 하나라,
    이어 붙이면 파서가 한 파일일 때와 똑같이 읽는다. `사전/` 바로 아래의
    `읽는법.md` 같은 설명 파일은 읽지 않는다.
    """
    import glob
    paths = sorted(glob.glob(os.path.join(DICT_DIR, "*", "*.md")))
    if not paths:
        raise OSError(f"{DICT_DIR} 아래 <분류>/<성분>.md 파일이 없습니다")
    parts = []
    for path in paths:
        with open(path, encoding="utf-8") as f:
            parts.append(f.read().strip())
    return "\n\n".join(parts) + "\n"

# 확인일이 이보다 오래되면 다시 보라고 알린다.
STALE_DAYS = 365


UID_RE = re.compile(r"^[0-9]+$")


def parse_dictionary(text):
    """성분사전에서 (성분, 주제, uid, sub, 주석이름) 목록과 확인일을 뽑는다.

    이건 YAML 파서가 아니라 좁은 정규식이다. 형식이 벗어나면 **에러 없이 그 성분을
    건너뛸 수 있다** — 실제로 "## 비타민 D"(성분명에 공백)가 통째로 빠진 적이 있다.
    그래서 제목은 줄 끝까지를 성분명으로 읽고(product_lookup.py 와 같은 규칙),
    빈 블록·중복 블록은 경고로 알린다.
    """
    entries = []
    checked = {}
    seen_headers = {}

    blocks = re.finditer(r"^## ([^\n]+?)\s*\n```yaml(.*?)```", text, re.S | re.M)
    for blk in blocks:
        ingredient, body = blk.group(1).strip(), blk.group(2)

        seen_headers.setdefault(ingredient, 0)
        seen_headers[ingredient] += 1

        m = re.search(r"^확인일:\s*(\S+)", body, re.M)
        checked[ingredient] = m.group(1) if m else None

        before = len(entries)

        for mm in re.finditer(r"^mesh_주제어:\n((?:\s+-\s*uid:.+\n(?:\s+sub:.+\n)?)+)", body, re.M):
            entries.extend(parse_mesh_items(ingredient, "성분", mm.group(1)))

        if "주제:" in body:
            angles = body[body.index("주제:"):]
            for am in re.finditer(r"^  (\S+):\s*\n(.*?)(?=^  \S+:|\Z)", angles, re.S | re.M):
                angle, ablock = am.group(1), am.group(2)
                for mm in re.finditer(r"mesh:\n((?:\s+-\s*uid:.+\n(?:\s+sub:.+\n)?)+)", ablock):
                    entries.extend(parse_mesh_items(ingredient, angle, mm.group(1)))

        if len(entries) == before:
            print(f"[경고] '{ingredient}' 블록에서 uid 항목을 하나도 못 읽었습니다 — "
                  "형식이 깨졌을 수 있습니다.", file=sys.stderr)

    dup = {k: v for k, v in seen_headers.items() if v > 1}
    if dup:
        for name, n in dup.items():
            print(f"[경고] '{name}' 블록이 {n}번 반복됩니다 — 나중 블록의 값으로 덮입니다. "
                  "사전에서 중복을 지우십시오.", file=sys.stderr)

    return entries, checked


def parse_mesh_items(ingredient, angle, block):
    """`- uid: 68014280  # Triglycerides` / `  sub: blood` 묶음을 읽는다."""
    items = []
    for line in block.split("\n"):
        m = re.match(r"\s*-\s*uid:\s*(\S+)\s*(?:#\s*(.*))?$", line)
        if m:
            items.append([ingredient, angle, m.group(1).strip(),
                          None, (m.group(2) or "").strip()])
            continue
        m = re.match(r"\s*sub:\s*(\S+)", line)
        if m and items:
            items[-1][3] = m.group(1).strip()
    return [tuple(i) for i in items]


def resolve_uids(uids, api_key=None):
    """번호 → 지금의 정식 MeSH 이름. 한 번의 호출로 전부 조회한다.

    이름이 아니라 번호를 사전에 두는 이유가 여기 있다. MeSH 이름은
    해마다 개명·폐기되지만 번호는 유지되므로, 번호로 물어보면 지금
    이름이 돌아온다. 폐기된 번호는 응답에 안 담기거나 이름이 비어
    돌아오므로 그 자리에서 알 수 있다.
    """
    params = {"db": "mesh", "retmode": "json", "id": ",".join(uids)}
    if api_key:
        params["api_key"] = api_key

    url = f"{EUTILS}/esummary.fcgi?{urllib.parse.urlencode(params)}"
    with urllib.request.urlopen(url, timeout=30) as resp:
        result = json.load(resp).get("result", {})

    names = {}
    for uid in result.get("uids", []):
        terms = result[uid].get("ds_meshterms") or []
        if terms:
            names[uid] = terms[0]
    return names


def check_mesh(term, api_key=None):
    """이 MeSH 이름으로 실제 논문이 잡히는가.

    PubMed는 없는 MeSH를 물어도 에러를 내지 않는다. 대신 응답의
    warninglist 에 phrasesnotfound / quotedphrasesnotfound 로 담아
    보내고 count 는 0이 된다. 그래서 건수만 보면 「그냥 논문이 없나
    보다」와 구분되지 않는다 — 반드시 warninglist 를 함께 본다.
    """
    params = {
        "db": "pubmed",
        "retmode": "json",
        "retmax": "0",
        "term": f'"{term}"[majr]',
    }
    if api_key:
        params["api_key"] = api_key

    url = f"{EUTILS}/esearch.fcgi?{urllib.parse.urlencode(params)}"
    with urllib.request.urlopen(url, timeout=20) as resp:
        data = json.load(resp)["esearchresult"]

    warn = data.get("warninglist", {})
    notfound = warn.get("phrasesnotfound", []) + warn.get("quotedphrasesnotfound", [])
    count = int(data.get("count", 0))

    if notfound:
        return False, count, "MeSH로 인식되지 않음"
    if count == 0:
        return False, count, "인식되나 논문 0건"
    return True, count, ""


def days_since(iso):
    """확인일로부터 며칠이 지났는지. 미래 날짜·형식 오류는 둘 다 None.

    음수(미래 날짜)를 그대로 반환하면 호출부의 `n > STALE_DAYS` 검사를
    통과해 "신선한 것"으로 오인된다 — 오타로 2027년을 적어도 잡히지
    않는다. 그래서 미래 날짜는 형식 오류와 같게 취급해 사람이 다시
    보게 만든다.
    """
    try:
        y, m, d = (int(x) for x in iso.split("-"))
        n = (date.today() - date(y, m, d)).days
        return None if n < 0 else n
    except Exception:  # noqa: BLE001 - 형식이 틀리면 오래된 것으로 본다
        return None


def main():
    only = sys.argv[1] if len(sys.argv) > 1 else None

    try:
        text = read_dictionary_text()
    except UnicodeDecodeError as e:
        print(f"[오류] 사전 파일이 UTF-8이 아닙니다: {e}", file=sys.stderr)
        sys.exit(2)
    except OSError as e:
        print(f"[오류] 사전 파일을 열 수 없습니다: {e}", file=sys.stderr)
        sys.exit(2)

    entries, checked = parse_dictionary(text)
    if only:
        entries = [e for e in entries if e[0] == only]
        if not entries:
            print(f"사전에 '{only}' 이(가) 없습니다.", file=sys.stderr)
            sys.exit(2)

    api_key = os.environ.get("NCBI_API_KEY")
    if not api_key:
        print("[안내] NCBI_API_KEY 미설정 — 항목마다 1초씩 쉬며 진행합니다\n",
              file=sys.stderr)

    bad_uid = [e for e in entries if not UID_RE.match(e[2])]
    if bad_uid:
        print("[오류] uid 형식이 아닌 항목이 있습니다:", file=sys.stderr)
        for ing, ang, uid, _sub, _note in bad_uid:
            print(f"  · {ing} / {ang} / {uid}", file=sys.stderr)
        sys.exit(2)

    # 1) 번호 → 지금 이름 (한 번의 호출로 전부)
    uids = sorted({e[2] for e in entries})
    try:
        names = resolve_uids(uids, api_key)
    except Exception as e:  # noqa: BLE001
        print(f"[오류] MeSH 번호 조회 실패: {e}", file=sys.stderr)
        sys.exit(3)

    dead = [u for u in uids if u not in names]

    print(f"{'성분':<8} {'주제':<12} {'지금 이름':<34} {'건수':>9}  판정")
    print("-" * 82)

    failed, renamed, unreachable = [], [], []
    for ingredient, angle, uid, sub, note in entries:
        name = names.get(uid)
        if not name:
            print(f"{ingredient:<8} {angle:<12} {'(번호 조회 실패)':<34} {'?':>9}  폐기된 MeSH")
            failed.append((ingredient, angle, uid, note, "번호가 조회되지 않음 — 폐기 가능성"))
            continue

        term = f"{name}/{sub}" if sub else name
        if note and note != name:
            renamed.append((ingredient, angle, uid, note, name))

        try:
            ok, count, reason = check_mesh(term, api_key)
        except Exception as e:  # noqa: BLE001 - 네트워크 문제는 판정 보류
            print(f"{ingredient:<8} {angle:<12} {term:<34} {'?':>9}  조회 실패 ({e})")
            unreachable.append((ingredient, angle, term))
            time.sleep(1.0)
            continue

        verdict = "OK" if ok else f"확인 필요 — {reason}"
        print(f"{ingredient:<8} {angle:<12} {term:<34} {count:>9}  {verdict}")
        if not ok:
            failed.append((ingredient, angle, uid, note, reason))
        time.sleep(0.15 if api_key else 1.0)

    print("-" * 82)

    if renamed:
        print(f"\n[MeSH 이름이 바뀌었습니다 {len(renamed)}건 — 검색은 정상입니다]")
        for ingredient, angle, uid, old, new in renamed:
            print(f"  · {ingredient} / {angle} / uid {uid}")
            print(f"      주석 \"{old}\" → 지금 이름 \"{new}\"")
        print("\n  번호로 찾으므로 검색에는 문제가 없습니다.")
        print("  사전의 `#` 주석만 지금 이름으로 고쳐 두면 읽기 편합니다.")

    if failed:
        print(f"\n[MeSH 확인 필요 {len(failed)}건]")
        for ingredient, angle, uid, note, reason in failed:
            print(f"  · {ingredient} / {angle} / uid {uid} ({note}) — {reason}")
        print("\n  아래에서 대체할 번호를 찾으십시오.")
        print("  https://www.ncbi.nlm.nih.gov/mesh/")
        print("  상위 결과를 그냥 쓰지 말고 정의(Scope Note)를 읽고 고르십시오.")
    elif unreachable:
        print(f"\n[조회 실패 {len(unreachable)}건 — 판정하지 못했습니다] 인터넷 연결을 확인하고 다시 돌리십시오.")
    elif not dead:
        print("\nMeSH 항목은 모두 유효합니다.")

    stale = []
    for ingredient in sorted({e[0] for e in entries}):
        iso = checked.get(ingredient)
        if iso is None:
            stale.append((ingredient, None))
            continue
        n = days_since(iso)
        if n is None or n > STALE_DAYS:
            stale.append((ingredient, n))

    if stale:
        print(f"\n[사람이 다시 봐야 할 성분 {len(stale)}건]")
        for ingredient, n in stale:
            when = "확인일 없음" if n is None else f"{n}일 지남"
            print(f"  · {ingredient} — {when}")
        print("\n  MeSH가 살아 있어도 아래는 기계가 확인할 수 없습니다.")
        print("    - `주의` 항목의 지침·권고가 아직 유효한가")
        print("    - `제외` 목록에 새 유사 성분을 넣을 것이 없는가")
        print("    - `주제` 가 지금 계정 전략과 맞는가")
        print("  확인했으면 그 성분 덩어리에 `확인일: YYYY-MM-DD` 를 적으십시오.")

    sys.exit(1 if failed else (3 if unreachable else 0))


if __name__ == "__main__":
    main()
