#!/usr/bin/env python3
"""
P7-1 원고 숫자 대조 — 큐레이션 원고에 나온 숫자가 전부 출처에 있는지 본다.

# 왜 필요한가

P5(`verify_numbers.py`)는 **점수 파일의 효과크기 칸**을 초록과 대조한다.
원고에 무엇이 실렸는지는 보지 않는다. 실제로 효과크기 칸에서는 지운
숫자(d=-1.020)가 채점 쪽 설명 문장을 타고 원고에 실린 적이 있다.
이 스크립트는 **최종 원고 자체**를 본다.

# 무엇을 어디서 찾나

| 원고의 숫자 | 있어야 하는 곳 | 없으면 |
|---|---|---|
| 효과 숫자 — 소수, 또는 단위(%·%p·배·mg·mmHg·천·만 …)가 붙은 숫자 (크기와 상관없이) | 논문 절 안: **그 논문의** 검증된 인용문(`verified: true`)·대상자·연평균인용·초록 원문(`--abstracts`) + 제품 표시 원문. 논문 절 밖: 모든 논문의 것 + 제품 표시 + 검색량 + 트렌드 기사 | **오류** (exit 5) |
| 정수 (표본·연도 등, 11 이상) | 위 전부 + 점수 파일·계정 프로필·성분사전의 모든 글 | 주의 (exit 0) |

- **그 논문의** — 원고의 그 줄에 나온 PMID와 그 줄이 속한 제목의 PMID. 「PMID 1과 2」처럼
  뒤쪽 번호에 PMID 가 안 붙어도 채점된 논문 번호면 알아본다. 다른 논문의 인용문에 있는 숫자를 가져다 써도 통과하지 않게 하려는 것이다.
  PMID가 없는 절(지금 화제·방어 소재 머리말 등)은 모든 출처와 대조한다
- **부호** — 원고에 음수로 적힌 숫자는 출처에도 음수로 있어야 한다
- 「8천」「1.5만」「1만 2천」은 8000·15000·12000 으로 바꿔 대조한다. 반올림한 숫자는 걸린다
- **DOI** — 원고의 DOI(링크 포함)는 점수 파일의 그 논문 `doi` 와 같아야 한다. 없는 DOI나
  다른 논문의 DOI는 오류다

트렌드 기사의 숫자는 논문처럼 검증된 값이 아니다. 여기서는 「출처가 아예 없는
숫자」만 막는다. 기사 수준이라는 표시가 붙었는지는 P7-2 검토가 본다.

보지 않는 것: PMID(단위 없이 쉼표 없는 6~9자리) · 날짜(2026-09-28, 2026.09.28, 2026-09,
2026년, 9월 28일) · 단위 없는 10 이하 정수(1순위, 3개 같은 것). 가운뎃점은 앞이 한 자리일 때만
소수점으로 읽는다 (Lancet 표기 `0·29` 는 0.29, `30·40대` 는 30 과 40).

`--abstracts F` 를 주면 원고에 나온 PMID의 초록을 PubMed에서 받아 F에 저장한다.
P7-2 검토 에이전트는 인터넷을 쓰지 않고 이 파일만 읽는다 — 초록을 무엇으로
읽었는지가 파일로 남아야 검토 지적도 다시 확인할 수 있다.

# 사용법

    python3 audit_numbers.py <원고.md> <점수-검증됨.json> [--trend F] [--volume F] [--product F]
                             [--out F] [--abstracts F]

exit 0 통과(주의는 있을 수 있음) / 2 입력 오류 / 5 출처 없는 효과 숫자
"""

import argparse
import glob
import json
import os
import re
import sys
import unicodedata

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 긴 것을 앞에 둔다 — 정규식은 왼쪽부터 맞춰 본다 ("mg/dL" 을 "mg" 로 끊지 않게)
UNITS = (r"%p|%포인트|%|배|천|만|mg/dL|mmol/L|nmol/L|ng/mL|mmHg|kcal|CFU|mcg|mg|μg|µg|kg|g|IU|iu|mL|ml")
# 앞에 영문자·숫자·소수점·쉼표가 붙으면 다른 토큰의 일부다. 한글은 막지 않는다 ("최대3.2배").
# 목록에 없는 단위라도 숫자에 바로 붙은 영문(4.7mmol, 3.1ms)은 단위로 본다 — 효과 숫자다
NUM_RE = re.compile(
    r"(?<![A-Za-z0-9.,])(?P<sign>[-−+]?)(?P<num>\d·\d+(?![·\d])|\d[\d,]*(?:\.\d+)?|\.\d+)"
    r"(?:\s*(?P<unit>" + UNITS + r")(?![A-Za-z])|(?P<attached>[A-Za-zμµ][A-Za-z/μµ]*))?")
# 소스 쪽에는 가운뎃점 소수(Lancet 표기 0·29)도 있을 수 있다
SRC_NUM_RE = re.compile(r"(?<![A-Za-z0-9.,])(?P<sign>[-−]?)(?P<num>\d[\d,]*(?:[.·]\d+)?|\.\d+)")
PMID_RE = re.compile(r"^\d{6,9}$")
DATE_RE = re.compile(r"\b(?:19|20)\d{2}[-./](?:0?[1-9]|1[0-2])(?:[-./](?:0?[1-9]|[12]\d|3[01]))?\b"
                     r"|(?<!\d)(?:19|20)\d{2}\s*년|(?<!\d)(?:0?[1-9]|1[0-2])\s*월(?:\s*(?:0?[1-9]|[12]\d|3[01])\s*일)?")
DOI_RE = re.compile(r"\b(10\.\d{4,9}/[^\s\)\]\}>\"'「」]+)", re.I)
MAN_CHEON_RE = re.compile(r"(\d+(?:\.\d+)?)\s*만\s*(\d+(?:\.\d+)?)\s*천")
CITED_RE = re.compile(r"PMID\s*(\d{6,9})|pubmed\.ncbi\.nlm\.nih\.gov/(\d{6,9})")
HEADING_RE = re.compile(r"^ {0,3}(#{1,6})\s")   # render_html.py 와 같은 규칙
SCALE = {"천": 1000, "만": 10000}


def die(msg):
    print(f"[오류] {msg}", file=sys.stderr)
    sys.exit(2)


def load_json(path, required=True):
    if not path:
        return None
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        if required:
            die(f"읽을 수 없습니다: {path} ({e})")
        return None


def canon(num):
    """비교용 표기 — 쉼표·가운뎃점·끝의 0 을 정리한 숫자 본체 (부호 없음)."""
    t = num.replace(",", "").replace("·", ".")
    if "." in t:
        whole, frac = t.split(".", 1)
        whole, frac = whole.lstrip("0") or "0", frac.rstrip("0")
        return whole + ("." + frac if frac else "")
    return t.lstrip("0") or "0"


def scaled(num, unit):
    try:
        return canon(str(round(float(num.replace(",", "")) * SCALE[unit])))
    except ValueError:
        return canon(num)


def numbers_in(text):
    """출처 글 → 숫자 집합. 부호 없는 형태와, 음수면 「-x」 형태를 함께 넣는다."""
    out = set()
    text = unicodedata.normalize("NFKC", text or "").replace("\u2212", "-")
    for m in SRC_NUM_RE.finditer(text):
        c = canon(m.group("num"))
        out.add(c)
        if m.group("sign"):
            out.add("-" + c)
    return out


def strings(x):
    if isinstance(x, str):
        yield x
    elif isinstance(x, (int, float)) and not isinstance(x, bool):
        yield str(x)
    elif isinstance(x, list):
        for i in x:
            yield from strings(i)
    elif isinstance(x, dict):
        for v in x.values():
            yield from strings(v)


def build_sources(scored, trend, volume, product, abstracts=None):
    """(논문별 효과 출처, 제품 표시값, 트렌드·검색량, 정수 출처, 모든 논문의 효과 출처)"""
    per_paper, product_nums, news, general = {}, set(), set(), set()

    for p in scored.get("논문", []):
        nums = set()
        e = p.get("효과크기")
        if isinstance(e, dict) and e.get("verified") is True:
            nums |= numbers_in(e.get("quote"))
        nums |= numbers_in(" ".join(strings(p.get("대상자"))))
        if p.get("연평균인용") is not None:
            nums |= numbers_in(str(p["연평균인용"]))
        nums |= numbers_in((abstracts or {}).get(str(p.get("pmid"))))   # PubMed에서 받은 초록 원문
        per_paper[str(p.get("pmid"))] = nums
        # 정수 출처: 폐기된 효과크기 칸을 뺀 모든 글 (폐기 숫자는 P5가 설명 문장에서 가렸다)
        rest = {k: v for k, v in p.items() if k != "효과크기"}
        general |= numbers_in(" ".join(strings(rest)))
    general |= numbers_in(" ".join(strings(scored.get("요약"))))

    for src in (trend, volume):
        if src:
            news |= numbers_in(" ".join(strings(src)))
    if product:
        sel = str(product.get("선택"))
        for c in product.get("후보", []):
            if str(c.get("신고번호")) == sel:
                product_nums |= numbers_in(" ".join(strings(c)))

    for path in glob.glob(os.path.join(ROOT, "계정", "*.md")) + glob.glob(os.path.join(ROOT, "사전", "*", "*.md")):
        try:
            general |= numbers_in(open(path, encoding="utf-8").read())
        except OSError:
            pass
    all_effect = set().union(*per_paper.values()) if per_paper else set()
    return per_paper, product_nums, news, general | product_nums | news | all_effect, all_effect


def doi_index(scored):
    """{소문자 doi: pmid}"""
    return {str(p["doi"]).strip().lower(): str(p.get("pmid")) for p in scored.get("논문", [])
            if isinstance(p.get("doi"), str) and p["doi"].strip()}


BARE_ID_RE = re.compile(r"(?<![\d,.])\d{6,9}(?![\d,.])")


def pmids_of(line, known=()):
    """줄에 나온 PMID. 「PMID 34057665와 34612056」·「(34057665)」 처럼 PMID 표기가 없어도
    채점된 논문 번호면 알아본다."""
    found = [m.group(1) or m.group(2) for m in CITED_RE.finditer(line)]
    if known:
        found += [x for x in BARE_ID_RE.findall(line) if x in known and x not in found]
    return found


def audit(md_text, per_paper, product_nums, news, general_src, all_effect, dois=None):
    errors, notes = [], []
    dois = dois or {}
    scope, scope_level = [], 0
    for ln, line in enumerate(md_text.splitlines(), 1):
        h = HEADING_RE.match(line)
        if h:
            level, found = len(h.group(1)), pmids_of(line, per_paper)
            if found:
                scope, scope_level = found, level
            elif level < scope_level or (level == scope_level and "후킹" not in line):
                scope, scope_level = [], 0   # 새 절 — 「### 후킹 초안」은 그 논문 절에 딸린 것으로 본다
        # 줄의 PMID + 그 줄이 속한 절의 PMID (방어 소재처럼 한 절이 여러 논문을 다룰 때)
        here = list(dict.fromkeys(pmids_of(line, per_paper) + scope))
        # 논문 절 안: 그 논문의 출처 + 제품 표시값(용량을 나란히 놓는 자리). 트렌드·검색량은 논문 절 밖에서만
        effect_src = (set().union(*(per_paper.get(p, set()) for p in here)) | product_nums) if here \
            else (all_effect | product_nums | news)

        clean = unicodedata.normalize("NFKC", line).replace("\u2212", "-")
        for d in dict.fromkeys(x.rstrip(".,;:") for x in DOI_RE.findall(clean)):
            owner = dois.get(d.lower())
            if owner is None:
                errors.append({"줄": ln, "숫자": d, "이유": "점수 파일에 없는 DOI", "문맥": line.strip()[:110]})
            elif here and owner not in here:
                errors.append({"줄": ln, "숫자": d, "이유": f"다른 논문(PMID {owner})의 DOI", "문맥": line.strip()[:110]})
        clean = DOI_RE.sub(" ", clean)
        clean = DATE_RE.sub(" ", clean)
        clean = re.sub(r"PMID\s*\d+|https?://\S+", " ", clean)
        clean = MAN_CHEON_RE.sub(lambda m: f"{(float(m.group(1)) * 10000 + float(m.group(2)) * 1000) / 10000:g}만", clean)
        for pid in here:
            clean = clean.replace(pid, " ")
        for m in NUM_RE.finditer(clean):
            num, unit, sign = m.group("num"), m.group("unit"), m.group("sign")
            raw = m.group(0).strip()
            if "," not in num and PMID_RE.match(num) and not (unit or m.group("attached")):
                continue
            is_effect = "." in num or "·" in num or bool(unit) or bool(m.group("attached"))
            c = scaled(num, unit) if unit in SCALE else canon(num)
            if not is_effect and c.isdigit() and int(c) <= 10:
                continue
            ctx = line.strip()[:110]
            if is_effect:
                key = "-" + c if sign == "-" else c
                if key not in effect_src:
                    why = "부호가 다름" if sign == "-" and c in effect_src else \
                          ("다른 논문의 숫자" if here and key in all_effect else "출처에 없음")
                    errors.append({"줄": ln, "숫자": raw, "이유": why, "문맥": ctx})
            elif c not in general_src:
                notes.append({"줄": ln, "숫자": raw, "문맥": ctx})
    return errors, notes


def cited_pmids(md_text):
    seen = []
    for m in CITED_RE.finditer(md_text):
        pmid = m.group(1) or m.group(2)
        if pmid not in seen:
            seen.append(pmid)
    return seen


def save_abstracts(pmids, path):
    """초록을 받아 {pmid: 초록} 으로 저장한다. 이미 받은 것은 다시 받지 않는다."""
    from verify_numbers import fetch_abstract
    import time

    saved = load_json(path, False) or {}
    api_key = os.environ.get("NCBI_API_KEY")
    failed = []
    for pmid in pmids:
        if pmid in saved:  # 초록이 없는 논문은 빈 문자열로 남는다
            continue
        try:
            saved[pmid] = fetch_abstract(pmid, api_key=api_key)
        except (RuntimeError, ValueError, LookupError) as e:
            failed.append(pmid)
            print(f"[안내] {e}", file=sys.stderr)
        time.sleep(0.12 if api_key else 0.4)
    write_json(path, saved)
    print(f"초록 저장: {len(pmids) - len(failed)}/{len(pmids)}편 → {path}")
    return failed


def write_json(path, data):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = f"{path}.tmp-{os.getpid()}"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def main():
    ap = argparse.ArgumentParser(description="큐레이션 원고 숫자 대조")
    ap.add_argument("md")
    ap.add_argument("scored")
    ap.add_argument("--trend")
    ap.add_argument("--volume")
    ap.add_argument("--product")
    ap.add_argument("--out", help="결과를 JSON으로 저장 (P7-2 검토가 읽는다)")
    ap.add_argument("--abstracts", help="원고에 나온 논문의 초록을 이 파일에 저장")
    a = ap.parse_args()

    try:
        md = open(a.md, encoding="utf-8").read()
    except OSError as e:
        die(f"원고를 읽을 수 없습니다: {a.md} ({e})")
    pmids = cited_pmids(md)
    failed = save_abstracts(pmids, a.abstracts) if a.abstracts else []
    abstracts = load_json(a.abstracts, False) if a.abstracts else None
    scored = load_json(a.scored)
    per_paper, product_nums, news, general_src, all_effect = build_sources(
        scored, load_json(a.trend, False), load_json(a.volume, False), load_json(a.product, False),
        abstracts)
    errors, notes = audit(md, per_paper, product_nums, news, general_src, all_effect, doi_index(scored))

    result = {"원고": a.md, "인용PMID": pmids, "초록못받음": failed,
              "오류": errors, "주의": notes,
              "판정": "통과" if not errors else "출처없는숫자"}
    if a.out:
        write_json(a.out, result)

    for e in errors:
        print(f"[오류] {e['줄']}행 「{e['숫자']}」 — {e['이유']} · {e['문맥']}", file=sys.stderr)
    for n in notes:
        print(f"[주의] {n['줄']}행 「{n['숫자']}」 — 원자료에서 찾지 못한 정수 · {n['문맥']}")
    print(f"숫자 대조: 오류 {len(errors)}건 · 주의 {len(notes)}건")
    sys.exit(5 if errors else 0)


if __name__ == "__main__":
    main()
