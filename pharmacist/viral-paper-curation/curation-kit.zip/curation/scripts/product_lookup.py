#!/usr/bin/env python3
"""
P0 제품 조회 — 식약처 식품안전나라 건강기능식품 품목제조신고(C003)에서
제품의 원료·함량·섭취량·주의사항을 원문 그대로 가져온다.

# 왜 스크립트인가

제품명만으로는 성분도 함량도 알 수 없다.

- 「알티지 오메가3 1200」의 1200은 **캡슐 무게**다. 함량이 아니다
- 같은 이름의 제품이 여러 회사에 있다. 1일 EPA+DHA가 600·1,000·1,200mg 으로 다르다
- 「식물성 알티지 오메가3」는 원재료가 **조류 유지**다. 성분사전이 오메가3에서
  제외하는 원료다. 이름만 보면 모른다

에이전트가 웹 페이지를 읽고 함량을 옮기면 숫자를 잘못 옮길 수 있다. 공식 신고
정보를 스크립트가 **원문 그대로** 가져오면 그 위험이 없다.

# 하는 일

1. `search` — 입력한 제품명을 몇 가지 형태로 바꿔 조회하고 후보를 모은다
   (「오메가3」↔「오메가-3」, 숫자 제거 등). 후보마다 성분사전의 `원료명` ·
   `제외원료명` 으로 **주성분 후보**와 **제외 원료 경고**를 붙이고, 기준규격에서
   `함량항목` 줄의 **표시량**을 뽑는다
2. `pick` — 사람이 고른 제품을 파일에 표시하고 **`제품/` 에 저장한다**

**고르는 것은 사람이다.** 이름이 가장 비슷한 제품이 찾던 제품이라는 보장이 없다.

# 제품 저장소 (`제품/`)

공구는 반복된다. 한 번 고른 제품은 `제품/<제품명>_<제조사>_<신고번호|웹>.json` 에 남기고,
그때 입력한 이름을 `입력별칭` 에 적는다. 제조사를 이름에 넣는 것은 이름이 같은 다른 회사
제품이 서로 덮어쓰지 않게 하려는 것이다. 한 입력 이름은 한 제품에만 붙는다 — 다른 제품을
고르면 그 이름은 옛 제품에서 떨어진다. 다음에 **같은 이름**(띄어쓰기·하이픈 무시)으로
`search` 하면 API를 부르지 않고 저장된 제품을 꺼낸다 — 식약처 조회와 제품 고르기를
건너뛴다. 이름이 비슷하기만 해서는 꺼내지 않는다. 그건 고르는 일이라 사람 몫이다.

조회한 지 `STALE_DAYS` 일이 지났으면 표시 사항이 바뀌었을 수 있어 다시 조회한다.
`--fresh` 를 주면 저장소를 보지 않는다. `제품/목록.md` 는 `pick` 할 때마다 다시 만든다.

# 키

환경변수 `FOODSAFETY_API_KEY`. 식품안전나라 로그인 → 데이터활용서비스 → 데이터공개 →
「건강기능식품 품목제조신고(원재료)」(C003) → Open-API 이용신청. 무료이고 바로 승인되며,
키는 「인증키 신청 현황」에 나온다. 호출 한도는 하루 1,000건이다 (한 번 조회에 2~6건). **키가 없으면 멈추지 않고** 안내와 빈 후보로 파일을
쓰고 exit 0 — 커맨드가 웹 검색(`product-reader`)으로 넘어간다.

# 사용법

    python3 product_lookup.py search "<제품명>" <출력.json> [--sample] [--fresh]
    python3 product_lookup.py pick <제품.json> <신고번호>

`--sample` 은 식품안전나라의 시험용 키로 조회한다 (결과가 5건으로 잘린다. 시험 전용).

exit 0 성공·키 없음 / 2 입력 오류 / 4 API 호출 실패 (파일은 안내와 함께 씀)
"""

import argparse
import datetime as dt
import http.client
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DICT_DIR = os.path.join(ROOT, "사전")
STORE = os.environ.get("PRODUCT_STORE") or os.path.join(ROOT, "제품")
STALE_DAYS = 180
# 키가 주소에 들어가므로 https 로 부른다
API = "https://openapi.foodsafetykorea.go.kr/api/{key}/C003/json/1/{n}/PRDLST_NM={q}"
PAGE = 100
MAX_CANDIDATES = 10


def die(msg, code=2):
    print(f"[오류] {msg}", file=sys.stderr)
    sys.exit(code)


def write(path, data):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = f"{path}.tmp-{os.getpid()}"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


# ---------------------------------------------------------------------------
# 성분사전에서 원료명·제외원료명·함량항목 읽기
# ---------------------------------------------------------------------------


def yaml_list(body, key):
    m = re.search(rf"^{key}:\s*(\[\]|#.*)?\n((?:\s+-\s*.+\n)*)", body, re.M)
    if not m:
        return []
    return [re.sub(r"\s+#.*$", "", x).strip()
            for x in re.findall(r"^\s+-\s*(.+)$", m.group(2), re.M)]


def load_dictionary():
    import glob
    paths = sorted(glob.glob(os.path.join(DICT_DIR, "*", "*.md")))    # 사전/<분류>/<성분>.md
    if not paths:
        die(f"성분사전 파일이 없습니다: {DICT_DIR}/<분류>/<성분>.md")
    try:
        text = "\n\n".join(open(x, encoding="utf-8").read().strip() for x in paths) + "\n"
    except OSError as e:
        die(f"성분사전을 읽을 수 없습니다 ({e})")
    out = {}
    for blk in re.finditer(r"^## ([^\n]+?)\s*\n```yaml(.*?)```", text, re.S | re.M):
        name, body = blk.group(1).strip(), blk.group(2)
        m = re.search(r"^함량항목:\s*(.+?)\s*(#.*)?$", body, re.M)
        out[name] = {
            "원료명": yaml_list(body, "원료명"),
            "제외원료명": yaml_list(body, "제외원료명"),
            "함량항목": m.group(1).strip() if m else None,
        }
    return out


# ---------------------------------------------------------------------------
# 조회
# ---------------------------------------------------------------------------


def query_variants(name):
    """입력을 조회용 이름 몇 개로 바꾼다. 앞쪽일수록 입력에 가깝다."""
    base = re.sub(r"\s+", " ", name).strip()
    no_num = re.sub(r"\b\d[\d,\.]*\s*(mg|g|mcg|μg|iu|IU)?\b", " ", base, flags=re.I)
    no_num = re.sub(r"\s+", " ", no_num).strip()
    v = [base, no_num]
    for s in (base, no_num):
        v.append(re.sub(r"오메가\s*3", "오메가-3", s))
        v.append(re.sub(r"오메가-3", "오메가3", s))
    tokens = [t for t in no_num.split() if len(t) >= 2]
    v += tokens
    seen, out = set(), []
    for x in v:
        if x and x not in seen:
            seen.add(x)
            out.append(x)
    return out


def call(key, q, n):
    url = API.format(key=key, n=n, q=urllib.parse.quote(q))
    with urllib.request.urlopen(url, timeout=30) as r:
        d = json.load(r)
    body = d.get("C003", {})
    code = (body.get("RESULT") or {}).get("CODE", "")
    if code not in ("INFO-000", "INFO-200"):      # 200 = 결과 없음
        raise RuntimeError(f"{code} {(body.get('RESULT') or {}).get('MSG')}")
    return body.get("row", []) or []


def score(name, product_name):
    """입력 토큰이 제품명에 몇 개 들어 있나 (띄어쓰기·하이픈 무시)."""
    norm = lambda s: re.sub(r"[\s\-·()]", "", s).lower()
    pn = norm(product_name)
    toks = [norm(t) for t in re.sub(r"오메가\s*-?\s*3", "오메가3", name).split() if t.strip()]
    pn = pn.replace("오메가-3", "오메가3")
    return sum(1 for t in toks if t and t in pn)


# ---------------------------------------------------------------------------
# 한 제품 레코드 해석
# ---------------------------------------------------------------------------

LABEL_RE = re.compile(r"표시량\s*\(\s*([^/()]+?)\s*/\s*([^()]+?)\s*\)")
# 「표시량(…)」 없이 「EPA와 DHA의합 : 500mg/4g 의 80~120%」 · 「마그네슘 150mg/2,400mg」 처럼 적은 신고도 있다
BARE_LABEL_RE = re.compile(r"(?:[:：]|\s)\s*(\d[\d,.]*\s*[^\d\s/()]+)\s*/\s*(\d[\d,.]*\s*[^\d\s/()의]+)")


def dose_line(stdr, item):
    """기준규격에서 함량항목 줄과 표시량을 원문 그대로 뽑는다.
    함량항목은 `|` 로 여러 표기를 적을 수 있고, 앞의 표기부터 찾는다."""
    if not item:
        return None
    lines = stdr.splitlines()
    for alt in item.split("|"):
        key = re.sub(r"\s+", "", alt)
        if not key:
            continue
        for i, line in enumerate(lines):
            if key in re.sub(r"\s+", "", line):
                m = LABEL_RE.search(line) or BARE_LABEL_RE.search(line)
                nxt = lines[i + 1].strip() if i + 1 < len(lines) else ""
                if not m and nxt.startswith("표시량"):   # 「EPA와 DHA의 합 :」 다음 줄에 「표시량(…)」
                    line = f"{line.strip()} {nxt}"
                    m = LABEL_RE.search(line)
                return {
                    "원문": line.strip(),
                    "표시량": m.group(1).strip() if m else None,
                    "기준중량": m.group(2).strip() if m else None,
                }
    return None


def interpret(row, dictionary):
    raw = row.get("RAWMTRL_NM") or ""
    fn = row.get("PRIMARY_FNCLTY") or ""
    stdr = row.get("STDR_STND") or ""
    blob = " ".join([raw, fn, stdr])
    matched, excluded = [], []
    for name, d in dictionary.items():
        if any(w and w.replace(" ", "") in blob.replace(" ", "") for w in d["원료명"]):
            matched.append(name)
        for w in d["제외원료명"]:
            if w and w in raw:
                excluded.append({"성분": name, "원료": w})
    doses = {n: dose_line(stdr, dictionary[n]["함량항목"]) for n in matched}
    # 주된기능성에 [원료명] 으로 원료별 기능성이 적힌 경우 — 복합 제품을 알아보는 단서.
    # 사전에 없는 원료(루테인 등)도 여기서 보인다
    functional = re.findall(r"\[([^\]]+)\]", fn)
    return {
        "신고번호": row.get("PRDLST_REPORT_NO"),
        "제품명": row.get("PRDLST_NM"),
        "제조사": row.get("BSSH_NM"),
        "성상": row.get("PRDT_SHAP_CD_NM"),
        "원재료": raw,
        "1일섭취량": row.get("NTK_MTHD"),
        "주된기능성": fn,
        "섭취시주의사항": row.get("IFTKN_ATNT_MATR_CN"),
        "기준규격": stdr,
        "주성분후보": matched,
        "표시된기능성원료": functional,
        "함량": doses,
        "제외원료경고": excluded,
        "출처": "식품안전나라 건강기능식품 품목제조신고 (C003)",
        "출처등급": "신고정보",
    }


# ---------------------------------------------------------------------------
# 제품 저장소
# ---------------------------------------------------------------------------


def alias_key(name):
    s = re.sub(r"오메가\s*-?\s*3", "오메가3", name or "")
    return re.sub(r"[\s\-·()_]", "", s).lower()


def slug(text):
    s = re.sub(r"[^\w가-힣]+", "-", (text or "").strip())
    return re.sub(r"-{2,}", "-", s).strip("-") or "제품"


def store_files():
    import glob
    return sorted(glob.glob(os.path.join(STORE, "*.json")))


def load_store():
    out = []
    for path in store_files():
        try:
            out.append((path, json.load(open(path, encoding="utf-8"))))
        except (OSError, json.JSONDecodeError):
            print(f"[안내] 제품 저장 파일을 읽지 못해 건너뜁니다: {os.path.basename(path)}", file=sys.stderr)
    return out


def find_saved(name):
    key = alias_key(name)
    hits = [(p, r) for p, r in load_store() if key in {alias_key(x) for x in r.get("입력별칭", [])}]
    if len(hits) > 1:   # 정상이면 생기지 않는다 (save_picked 가 별칭을 옮긴다). 생기면 고르지 않는다
        names = ", ".join(os.path.basename(p) for p, _ in hits)
        print(f"[안내] 「{name}」이 저장된 제품 {len(hits)}개에 걸려 있어 다시 조회합니다: {names}")
        return None, None
    return hits[0] if hits else (None, None)


def save_picked(cand, input_name, looked_up):
    os.makedirs(STORE, exist_ok=True)
    no = str(cand.get("신고번호"))
    tail = "웹" if no.startswith("웹") else no
    path = os.path.join(STORE, f"{slug(cand.get('제품명'))}_{slug(cand.get('제조사'))}_{tail}.json")
    old = {}
    if os.path.exists(path):
        try:
            old = json.load(open(path, encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            old = {}
    others = [(p, r) for p, r in load_store() if p != path]
    taken = {alias_key(x) for _, r in others for x in r.get("입력별칭", [])}
    aliases = list(old.get("입력별칭", []))
    have = {alias_key(y) for y in aliases}
    if input_name and alias_key(input_name) not in have:
        aliases.append(input_name)
        have.add(alias_key(input_name))
    # 제품명은 **다른 제품이 쓰지 않을 때만** 별칭으로 붙인다. 「오메가-3」처럼 여러 회사가 같은
    # 이름을 쓰면, 자동으로 붙인 이름이 사람이 고른 다른 제품의 별칭을 빼앗게 된다
    name = cand.get("제품명")
    if name and alias_key(name) not in have and alias_key(name) not in taken:
        aliases.append(name)
    write(path, {"조회일": looked_up, "입력별칭": aliases, "제품": cand})
    # 사람이 넣은 이름이 다른 제품에 붙어 있으면 떼어 낸다 — 이제 이 이름은 이 제품이다
    mine = alias_key(input_name) if input_name else None
    for other, rec in others:
        kept = [x for x in rec.get("입력별칭", []) if alias_key(x) != mine]
        if len(kept) != len(rec.get("입력별칭", [])):
            rec["입력별칭"] = kept
            write(other, rec)
            print(f"  별칭 이동: {os.path.basename(other)} 에서 「{input_name}」을 뗌")
    write_index()
    return path


def write_index():
    lines = ["# 제품 목록", "",
             "`/큐레이션` 에서 고른 제품입니다. `scripts/product_lookup.py pick` 이 만듭니다 — "
             "직접 고치면 다음에 덮어써집니다.", "",
             "| 제품명 | 제조사 | 성분 | 함량 | 조회일 | 이 이름으로 넣으면 바로 씀 | 파일 |",
             "|---|---|---|---|---|---|---|"]
    for path, rec in load_store():
        c = rec.get("제품") or {}
        dose = "; ".join(f"{v['표시량']}" for v in (c.get("함량") or {}).values() if v and v.get("표시량")) or "-"
        lines.append(f"| {c.get('제품명')} | {c.get('제조사')} | {', '.join(c.get('주성분후보') or []) or '-'} "
                     f"| {dose} | {rec.get('조회일')} | {', '.join(rec.get('입력별칭', []))} "
                     f"| `{os.path.basename(path)}` |")
    path = os.path.join(STORE, "목록.md")
    tmp = f"{path}.tmp-{os.getpid()}"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    os.replace(tmp, path)


# ---------------------------------------------------------------------------


def cmd_search(a):
    dictionary = load_dictionary()
    result = {
        "입력": a.name,
        "조회일": dt.date.today().isoformat(),
        "조회어": [],
        "후보": [],
        "선택": None,
        "안내": None,
    }
    if not a.fresh:
        path, rec = find_saved(a.name)
        if rec:
            try:
                age = (dt.date.today() - dt.date.fromisoformat(str(rec.get("조회일")))).days
            except ValueError:
                age = STALE_DAYS + 1   # 조회일이 없거나 깨졌으면 오래된 것으로 본다
            if age <= STALE_DAYS:
                c = rec["제품"]
                result.update({"조회일": rec["조회일"], "후보": [c], "선택": str(c.get("신고번호")),
                               "저장됨": os.path.relpath(path, ROOT),
                               "안내": f"전에 고른 제품입니다 ({rec['조회일']} 조회) — 다시 찾으려면 --fresh"})
                write(a.out, result)
                print(f"저장된 제품: {c['제품명']} | {c['제조사']} | {rec['조회일']} 조회")
                print(f"→ {a.out}")
                return
            print(f"[안내] 저장된 제품이 {age}일 전 조회라 다시 조회합니다: {os.path.basename(path)}")
    key = "sample" if a.sample else os.environ.get("FOODSAFETY_API_KEY")
    if not key:
        result["안내"] = "FOODSAFETY_API_KEY 가 없어 식약처 조회를 건너뜁니다 — 웹 검색으로 찾습니다"
        write(a.out, result)
        print(f"[안내] {result['안내']}")
        sys.exit(0)

    n = 5 if a.sample else PAGE
    rows = {}
    try:
        for q in query_variants(a.name):
            got = call(key, q, n)
            result["조회어"].append({"조회어": q, "건수": len(got)})
            for r in got:
                rows.setdefault(r.get("PRDLST_REPORT_NO"), r)
            time.sleep(0.2)
    except (OSError, http.client.HTTPException, json.JSONDecodeError, RuntimeError) as e:
        result["안내"] = f"식약처 조회 실패 ({e}) — 웹 검색으로 찾습니다"
        write(a.out, result)
        print(f"[오류] {result['안내']}", file=sys.stderr)
        sys.exit(4)

    ranked = sorted(rows.values(), key=lambda r: (-score(a.name, r.get("PRDLST_NM") or ""),
                                                   len(r.get("PRDLST_NM") or "")))
    result["후보"] = [interpret(r, dictionary) for r in ranked[:MAX_CANDIDATES]]
    if not result["후보"]:
        result["안내"] = "식약처 신고 정보에서 제품을 찾지 못했습니다 — 웹 검색으로 찾습니다"
    write(a.out, result)

    print(f"후보 {len(result['후보'])}개 (조회 {len(result['조회어'])}회)")
    for i, c in enumerate(result["후보"], 1):
        main = ",".join(c["주성분후보"]) or "사전 성분 없음"
        dose = "; ".join(f"{k} {v['표시량']}" for k, v in c["함량"].items() if v and v["표시량"]) or "-"
        warn = "  ⚠ 제외원료: " + ",".join(x["원료"] for x in c["제외원료경고"]) if c["제외원료경고"] else ""
        print(f"  {i}. {c['제품명']} | {c['제조사']} | {main} | {dose}{warn}")
    print(f"→ {a.out}")


def cmd_pick(a):
    try:
        data = json.load(open(a.file, encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as e:
        die(f"제품 파일을 읽을 수 없습니다: {a.file} ({e})")
    hit = [c for c in data.get("후보", []) if str(c.get("신고번호")) == a.report_no]
    if not hit:
        die(f"후보에 없는 신고번호입니다: {a.report_no}")
    data["선택"] = a.report_no
    write(a.file, data)
    c = hit[0]
    saved = save_picked(c, data.get("입력"), data.get("조회일") or dt.date.today().isoformat())
    print(f"선택: {c['제품명']} ({c['제조사']}) · 주성분 후보 {c.get('주성분후보')}")
    print(f"저장: {os.path.relpath(saved, ROOT)} — 다음에 「{data.get('입력')}」으로 넣으면 바로 씁니다")


def main():
    ap = argparse.ArgumentParser(description="식약처 건강기능식품 품목 조회")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("search")
    p.add_argument("name")
    p.add_argument("out")
    p.add_argument("--sample", action="store_true", help="식품안전나라 시험용 키 (5건 제한)")
    p.add_argument("--fresh", action="store_true", help="제품/ 에 저장된 것을 보지 않고 다시 조회")
    p.set_defaults(fn=cmd_search)
    p = sub.add_parser("pick")
    p.add_argument("file")
    p.add_argument("report_no")
    p.set_defaults(fn=cmd_pick)
    a = ap.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
