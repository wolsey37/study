#!/usr/bin/env python3
"""
발행 기록 — 큐레이션에서 실제로 쓴 논문과 그 반응을 남긴다.

# 왜 필요한가

바이럴 점수는 가설이다. 화제성 25 · 최신성 20 … 은 「이런 논문이 잘
퍼질 것이다」라는 추측이지, 실제 조회수로 맞춰 본 배점이 아니다.
**실제 반응을 적어 두지 않으면 그 추측이 맞는지 영영 알 수 없다.**

그리고 공구는 반복된다. 지난달에 쓴 PMS 메타분석을 이번 달 큐레이션이
또 1순위로 올려도, 기록이 없으면 아무도 모른다.

이 파일 하나가 두 가지를 한다.

1. **이미 쓴 논문 표시** — `annotate` 가 점수 파일에 `사용이력` 을 붙이고,
   큐레이션에 「🔁 이미 씀」 이 뜬다. 빼지는 않는다 — 다시 쓸지는 사람이 정한다
2. **배점 보정 근거** — `report` 가 바이럴 점수와 실제 반응(저장·조회)의
   순위 상관을 낸다. 어느 축이 반응을 맞히고 어느 축이 헛도는지 보인다

# 기록 파일

`발행/발행기록.json`. 사람이 직접 고쳐도 되지만, `react` 로 넣는 편이
오타가 없다.

# 사용법

    python3 publish_log.py add <점수파일> <pmid> [<pmid> ...] [--date D] [--account A]
    python3 publish_log.py react <pmid> [--views N] [--saves N] [--comments N] [--shares N] [--date D]
    python3 publish_log.py used <성분>
    python3 publish_log.py annotate <점수파일>
    python3 publish_log.py report [<성분>] [--product <신고번호>]

`add` 는 점수 파일이 있는 실행 폴더의 `실행.json` 에서 제품(신고번호·제품명)과
실행 폴더 이름을 함께 남긴다. 같은 성분이라도 제품별로 반응을 볼 수 있다.

exit 0 성공 / 2 입력 오류
"""

import argparse
import datetime as dt
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# PUBLISH_LOG 로 다른 파일을 가리킬 수 있다 (시험할 때 실제 기록을 건드리지 않으려고)
LOG = os.environ.get("PUBLISH_LOG") or os.path.join(ROOT, "발행", "발행기록.json")
REACTIONS = ("조회", "저장", "댓글", "공유")
AXES = ("화제성", "최신성", "숫자가용성", "의외성", "오디언스적합")
MIN_FOR_CORR = 5        # 이보다 적으면 상관을 내지 않는다 — 우연과 구분이 안 된다


def die(msg, code=2):
    print(f"[오류] {msg}", file=sys.stderr)
    sys.exit(code)


def load_log():
    if not os.path.exists(LOG):
        return {"기록": []}
    try:
        with open(LOG, encoding="utf-8") as f:
            data = json.load(f)
    except json.JSONDecodeError as e:
        die(f"{LOG} 를 읽을 수 없습니다 — 손으로 고치다 JSON이 깨졌을 수 있습니다 ({e})")
    if not isinstance(data.get("기록"), list):
        die(f"{LOG} 에 `기록` 배열이 없습니다")
    return data


def save_log(data):
    os.makedirs(os.path.dirname(LOG), exist_ok=True)
    tmp = f"{LOG}.tmp-{os.getpid()}"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, LOG)


def load_scored(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        die(f"점수 파일을 읽을 수 없습니다: {path} ({e})")


# ---------------------------------------------------------------------------


def run_info(scored_path):
    """점수 파일(<실행>/과정/점수-…json)의 실행 폴더와 제품."""
    run = os.path.dirname(os.path.dirname(os.path.abspath(scored_path)))
    try:
        with open(os.path.join(run, "실행.json"), encoding="utf-8") as f:
            m = json.load(f)
    except (OSError, json.JSONDecodeError):
        return None, None
    prod = m.get("제품")
    if prod:
        prod = {"신고번호": prod.get("신고번호"), "제품명": prod.get("제품명")}
    return os.path.basename(run), prod


def cmd_add(a):
    scored = load_scored(a.scored)
    run, prod = run_info(a.scored)
    by_pmid = {str(p.get("pmid")): p for p in scored.get("논문", [])}
    missing = [x for x in a.pmids if x not in by_pmid]
    if missing:
        die(f"점수 파일에 없는 PMID: {', '.join(missing)} — 큐레이션에 실린 논문만 기록합니다")

    date = a.date or dt.date.today().isoformat()
    log = load_log()
    account = a.account or scored.get("계정")
    for pmid in a.pmids:
        if any(r["pmid"] == pmid and r["발행일"] == date and r.get("계정") == account for r in log["기록"]):
            print(f"  이미 있음: {pmid} · {date} · {account} — 건너뜀")
            continue
        p = by_pmid[pmid]
        log["기록"].append({
            "pmid": pmid,
            "제목": p.get("제목"),
            "성분": scored.get("성분"),
            "주제": p.get("출처주제"),
            "계정": account,
            "제품": prod,
            "실행": run,
            "발행일": date,
            "총점": p.get("총점"),
            "점수": p.get("점수"),
            "근거등급경고": p.get("경고") or [],
            "반응": {k: None for k in REACTIONS},
            "메모": None,
        })
        print(f"  기록: {pmid} · {p.get('출처주제')} · 총점 {p.get('총점')} · {date}")
    save_log(log)
    print(f"→ {LOG} ({len(log['기록'])}건)")


def cmd_react(a):
    log = load_log()
    hits = [r for r in log["기록"] if r["pmid"] == a.pmid and (not a.date or r["발행일"] == a.date)]
    if not hits:
        die(f"기록에 없는 PMID입니다: {a.pmid}" + (f" (발행일 {a.date})" if a.date else ""))
    rec = sorted(hits, key=lambda r: r["발행일"])[-1]      # 같은 논문을 여러 번 썼으면 가장 최근 것
    given = {"조회": a.views, "저장": a.saves, "댓글": a.comments, "공유": a.shares}
    if all(v is None for v in given.values()):
        die("--views/--saves/--comments/--shares 중 하나는 넣어야 합니다")
    for k, v in given.items():
        if v is not None:
            if v < 0:
                die(f"{k} 는 0 이상이어야 합니다")
            rec["반응"][k] = v
    save_log(log)
    print(f"  반응 기록: {a.pmid} ({rec['발행일']}) → {rec['반응']}")


def cmd_used(a):
    log = load_log()
    rows = [{"pmid": r["pmid"], "주제": r.get("주제"), "발행일": r["발행일"], "계정": r.get("계정")}
            for r in log["기록"] if r.get("성분") == a.ingredient]
    print(json.dumps(rows, ensure_ascii=False, indent=2))


def cmd_annotate(a):
    scored = load_scored(a.scored)
    log = load_log()
    hist = {}
    for r in log["기록"]:
        hist.setdefault(r["pmid"], []).append({"발행일": r["발행일"], "계정": r.get("계정")})
    n = 0
    for p in scored.get("논문", []):
        used = sorted(hist.get(str(p.get("pmid")), []), key=lambda x: x["발행일"])
        p["사용이력"] = used
        n += bool(used)
    tmp = f"{a.scored}.tmp-{os.getpid()}"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(scored, f, ensure_ascii=False, indent=2)
    os.replace(tmp, a.scored)
    print(f"사용이력 표시: {len(scored.get('논문', []))}편 중 {n}편이 이미 쓴 논문")


# ---------------------------------------------------------------------------


def ranks(xs):
    """평균 순위 (동점은 같은 순위의 평균)."""
    order = sorted(range(len(xs)), key=lambda i: xs[i])
    r = [0.0] * len(xs)
    i = 0
    while i < len(order):
        j = i
        while j + 1 < len(order) and xs[order[j + 1]] == xs[order[i]]:
            j += 1
        avg = (i + j) / 2 + 1
        for k in range(i, j + 1):
            r[order[k]] = avg
        i = j + 1
    return r


def spearman(xs, ys):
    rx, ry = ranks(xs), ranks(ys)
    n = len(xs)
    mx, my = sum(rx) / n, sum(ry) / n
    cov = sum((a - mx) * (b - my) for a, b in zip(rx, ry))
    vx = sum((a - mx) ** 2 for a in rx) ** 0.5
    vy = sum((b - my) ** 2 for b in ry) ** 0.5
    return None if vx == 0 or vy == 0 else cov / (vx * vy)


def cmd_report(a):
    log = load_log()
    recs = [r for r in log["기록"] if (not a.ingredient or r.get("성분") == a.ingredient)
            and (not a.product or str((r.get("제품") or {}).get("신고번호")) == a.product)]
    if not recs:
        print("기록이 없습니다.")
        return

    print(f"{'발행일':<11} {'PMID':<10} {'주제':<14} {'총점':>4}  {'조회':>7} {'저장':>6}")
    for r in sorted(recs, key=lambda r: r["발행일"]):
        rv = r.get("반응") or {}
        f = lambda v: "-" if v is None else f"{v:,}"
        print(f"{r['발행일']:<11} {r['pmid']:<10} {str(r.get('주제')):<14} "
              f"{r.get('총점') or '-':>4}  {f(rv.get('조회')):>7} {f(rv.get('저장')):>6}")

    print()
    computed = False
    for target in ("저장", "조회"):
        rows = [r for r in recs if (r.get("반응") or {}).get(target) is not None
                and isinstance(r.get("총점"), (int, float))]
        if len(rows) < MIN_FOR_CORR:
            print(f"[{target}] 반응이 기록된 논문 {len(rows)}건 — "
                  f"{MIN_FOR_CORR}건 이상 쌓이면 점수와 반응의 상관을 냅니다")
            continue
        y = [r["반응"][target] for r in rows]
        rho = spearman([r["총점"] for r in rows], y)
        computed = True
        print(f"[{target}] {len(rows)}건 · 총점과의 순위상관 ρ = "
              f"{'계산 불가' if rho is None else f'{rho:+.2f}'}")
        for ax in AXES:
            xs = [(r.get("점수") or {}).get(ax) for r in rows]
            if any(x is None for x in xs):
                continue
            rho = spearman(xs, y)
            if rho is not None:
                print(f"    {ax:<8} ρ = {rho:+.2f}")
    if computed:
        print()
        print("ρ 가 +0.3 이상이면 그 축이 반응을 어느 정도 맞히고, 0 근처나 음수면 헛돌고 있습니다.")
        print("헛도는 축은 p4-viral-scorer.md 의 배점표에서 비중을 줄이십시오 "
              "(validate_schema.py 의 VALID_AXIS_SCORES 도 같이 고칩니다).")


def iso_date(text):
    try:
        return dt.date.fromisoformat(text).isoformat()
    except ValueError:
        raise argparse.ArgumentTypeError(f"날짜가 아닙니다: {text} — YYYY-MM-DD")


def count(text):
    if not text.isdigit():
        raise argparse.ArgumentTypeError(f"0 이상의 정수가 아닙니다: {text}")
    return int(text)


def main():
    ap = argparse.ArgumentParser(description="발행 기록")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("add", help="큐레이션에서 쓸 논문을 기록")
    p.add_argument("scored")
    p.add_argument("pmids", nargs="+")
    p.add_argument("--date", type=iso_date)
    p.add_argument("--account")
    p.set_defaults(fn=cmd_add)

    p = sub.add_parser("react", help="발행 후 반응을 기록")
    p.add_argument("pmid")
    p.add_argument("--date", type=iso_date, help="같은 논문을 여러 번 썼을 때 어느 발행인지")
    for flag in ("views", "saves", "comments", "shares"):
        p.add_argument(f"--{flag}", type=count)
    p.set_defaults(fn=cmd_react)

    p = sub.add_parser("used", help="그 성분에서 이미 쓴 논문 목록")
    p.add_argument("ingredient")
    p.set_defaults(fn=cmd_used)

    p = sub.add_parser("annotate", help="점수 파일에 사용이력을 붙임")
    p.add_argument("scored")
    p.set_defaults(fn=cmd_annotate)

    p = sub.add_parser("report", help="점수와 실제 반응 비교")
    p.add_argument("ingredient", nargs="?")
    p.add_argument("--product", help="이 제품(신고번호)으로 쓴 기록만")
    p.set_defaults(fn=cmd_report)

    a = ap.parse_args()
    for pmid in getattr(a, "pmids", []) or []:
        if not pmid.isdigit():
            die(f"PMID는 숫자여야 합니다: {pmid}")
    if getattr(a, "pmid", None) and not a.pmid.isdigit():
        die(f"PMID는 숫자여야 합니다: {a.pmid}")
    a.fn(a)


if __name__ == "__main__":
    main()
