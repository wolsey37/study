#!/usr/bin/env python3
"""
PubMed 조회 — 에이전트와 명령이 PubMed를 부를 때 쓰는 유일한 창구.

# 왜 스크립트인가

에이전트가 curl 명령을 직접 짜면 따옴표·URL 인코딩에서 틀린다. 값에 공백이 있는
검색식을 잘못 넣으면 200 OK에 빈 응답이 와서 에러도 없이 0건이 된다. 키 처리·호출
간격·재시도도 에이전트마다 제각각이 된다. 이 스크립트가 그것을 한 곳에서 한다.

**초록은 `verify_numbers.py` 와 같은 함수로 받는다.** 검색 담당이 읽는 초록, 채점이
인용문을 뜨는 초록, 검증이 대조하는 초록이 글자 하나까지 같아야 한다. 받은 초록은
`캐시/초록/` 에 두고 셋이 같이 쓴다.

# 사용법

    python3 pubmed.py search "<검색식>" [--from 2019] [--to 2026] [--max 20] [--sort relevance|pub_date]
    python3 pubmed.py count "<검색식>" [--from 2019] [--to 2026]
    python3 pubmed.py fetch <pmid> [<pmid> ...] [--out 파일]
    python3 pubmed.py mesh <uid> [<uid> ...]
    python3 pubmed.py check-mesh "<키워드>"
    python3 pubmed.py mesh-find "<영문 성분명>" [--max 10]
    python3 pubmed.py cites <pmid> [<pmid> ...]

결과는 JSON 으로 출력한다 (`--out` 을 주면 파일에).

- `search` — 건수와 PMID 목록. `해석` 은 PubMed가 검색식을 어떻게 읽었는지, `없는구절` 은
  PubMed가 모르는 말이다 (비어 있지 않으면 그 조건은 조용히 무시되거나 0건이 된다)
- `fetch` — 논문마다 제목·초록·논문유형(PT)·연도·저널·DOI. 초록은 XML 원문 그대로다
- `mesh` — 사전의 MeSH 번호를 지금 이름으로. 조회되지 않는 번호는 `null` (폐기된 MeSH)
- `check-mesh` — 그 말이 정식 MeSH 주제어인지. 아니면 `[tiab]` 로 내려가야 한다
- `cites` — 인용수·연평균인용·오픈액세스. PubMed는 인용수를 주지 않아 **Europe PMC** 에서 받는다.
  연평균인용 = 인용수 ÷ max(올해 − 출판연도, 1). 없는 PMID는 `null`
- `mesh-find` — 사전에 없는 성분의 MeSH 후보. 정의·논문 건수를 붙인다. **1위를 자동으로
  쓰지 않는다** — 고르는 것은 사람이다

환경변수 `NCBI_API_KEY` 가 있으면 붙인다 (초당 10회). 없으면 초당 3회에 맞춰 쉰다.

exit 0 성공 / 2 입력 오류 / 4 PubMed 호출 실패
"""

import argparse
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from verify_numbers import ABSTRACT_CACHE, EUTILS, normalize  # noqa: E402

PMID_RE = re.compile(r"^\d+$")
BATCH = 100


def die(msg, code=2):
    print(f"[오류] {msg}", file=sys.stderr)
    sys.exit(code)


def api_key():
    return os.environ.get("NCBI_API_KEY") or None


def pause():
    time.sleep(0.12 if api_key() else 0.4)


def call(endpoint, params, retries=3, raw=False):
    params = dict(params)
    if api_key():
        params["api_key"] = api_key()
    data = urllib.parse.urlencode(params).encode()
    last = None
    for attempt in range(retries):
        try:
            # POST — 긴 검색식·PMID 목록도 URL 길이 제한에 걸리지 않는다
            with urllib.request.urlopen(f"{EUTILS}/{endpoint}", data=data, timeout=40) as r:
                body = r.read()
            pause()
            return body if raw else json.loads(body)
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as e:
            last = e
            time.sleep(1.5 * (attempt + 1))
    die(f"PubMed 호출 실패 ({endpoint}): {last}", 4)


def with_dates(term, date_from, date_to):
    if date_from or date_to:
        return f'({term}) AND ("{date_from or 1800}"[dp] : "{date_to or 3000}"[dp])'
    return term


def esearch(term, retmax, sort=None):
    params = {"db": "pubmed", "retmode": "json", "retmax": str(retmax), "term": term}
    if sort:
        params["sort"] = sort
    r = call("esearch.fcgi", params)["esearchresult"]
    warn = r.get("warninglist", {}) or {}
    return {
        "검색식": term,
        "건수": int(r.get("count", 0)),
        "pmids": r.get("idlist", []),
        "해석": r.get("querytranslation"),
        "없는구절": (warn.get("phrasesnotfound") or []) + (warn.get("quotedphrasesnotfound") or []),
    }


# ---------------------------------------------------------------------------


def cmd_search(a):
    out = esearch(with_dates(a.term, a.date_from, a.date_to), a.max, a.sort)
    emit(out, a.out)


def cmd_count(a):
    r = esearch(with_dates(a.term, a.date_from, a.date_to), 0)
    emit({k: r[k] for k in ("검색식", "건수", "해석", "없는구절")}, a.out)


def text(el):
    return "".join(el.itertext()) if el is not None else None


def parse_article(art):
    """PubmedArticle 하나 → 필요한 칸. 초록은 verify_numbers.fetch_abstract 와 같은 방식으로 만든다."""
    pmid = text(art.find(".//MedlineCitation/PMID"))
    parts = ["".join(ab.itertext()) for ab in art.iter("AbstractText")]
    abstract = normalize(" ".join(parts))
    year = text(art.find(".//JournalIssue/PubDate/Year")) or text(art.find(".//ArticleDate/Year"))
    if not year:
        md = text(art.find(".//JournalIssue/PubDate/MedlineDate")) or ""
        m = re.search(r"\d{4}", md)
        year = m.group(0) if m else None
    doi = None
    for aid in art.iter("ArticleId"):
        if aid.get("IdType") == "doi":
            doi = (aid.text or "").strip() or None
    return {
        "pmid": pmid,
        "제목": normalize(text(art.find(".//ArticleTitle")) or ""),
        "초록": abstract,
        "초록없음": not abstract,
        "논문유형": [normalize(text(pt)) for pt in art.iter("PublicationType")],
        "연도": int(year) if year and year.isdigit() else None,
        "저널": text(art.find(".//Journal/ISOAbbreviation")) or text(art.find(".//Journal/Title")),
        "doi": doi,
    }


def save_cache(pmid, abstract):
    if not abstract:
        return   # 초록이 없는 논문은 남기지 않는다 — 나중에 붙을 수 있다
    os.makedirs(ABSTRACT_CACHE, exist_ok=True)
    path = os.path.join(ABSTRACT_CACHE, f"{pmid}.txt")
    tmp = f"{path}.tmp-{os.getpid()}"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(abstract)
    os.replace(tmp, path)


def cmd_fetch(a):
    bad = [p for p in a.pmids if not PMID_RE.match(p)]
    if bad:
        die(f"PMID 형식이 아님: {bad}")
    ids = list(dict.fromkeys(a.pmids))
    found = {}
    for i in range(0, len(ids), BATCH):
        chunk = ids[i:i + BATCH]
        body = call("efetch.fcgi", {"db": "pubmed", "id": ",".join(chunk), "retmode": "xml"}, raw=True)
        try:
            root = ET.fromstring(body)
        except ET.ParseError as e:
            die(f"PubMed 응답을 읽을 수 없음: {e}", 4)
        for art in root.iter("PubmedArticle"):
            rec = parse_article(art)
            found[rec["pmid"]] = rec
            save_cache(rec["pmid"], rec["초록"])
    missing = [p for p in ids if p not in found]
    emit({"논문": [found[p] for p in ids if p in found], "없는PMID": missing}, a.out)
    if missing:
        print(f"[안내] PubMed에 없는 PMID: {missing}", file=sys.stderr)


def cmd_mesh(a):
    bad = [u for u in a.uids if not PMID_RE.match(u)]
    if bad:
        die(f"MeSH 번호 형식이 아님: {bad}")
    r = call("esummary.fcgi", {"db": "mesh", "retmode": "json", "id": ",".join(a.uids)})["result"]
    out = {}
    for u in a.uids:
        terms = (r.get(u) or {}).get("ds_meshterms") or []
        out[u] = terms[0] if terms else None
    emit({"이름": out, "조회실패": [u for u, n in out.items() if n is None]}, a.out)


def cmd_check_mesh(a):
    r = esearch(f'"{a.keyword}"[majr]', 0)
    is_mesh = not r["없는구절"] and r["건수"] > 0
    emit({"키워드": a.keyword, "MeSH": is_mesh, "건수": r["건수"], "없는구절": r["없는구절"],
          "쓰는법": f'"{a.keyword}"[majr]' if is_mesh else f'"{a.keyword}"[tiab]'}, a.out)


def cmd_mesh_find(a):
    ids = call("esearch.fcgi", {"db": "mesh", "retmode": "json", "retmax": str(a.max),
                                "term": a.term})["esearchresult"].get("idlist", [])
    if not ids:
        emit({"검색어": a.term, "후보": []}, a.out)
        return
    r = call("esummary.fcgi", {"db": "mesh", "retmode": "json", "id": ",".join(ids)})["result"]
    cands = []
    for rank, u in enumerate(ids, 1):
        rec = r.get(u) or {}
        name = (rec.get("ds_meshterms") or [None])[0]
        count = esearch(f'"{name}"[majr]', 0)["건수"] if name else None
        cands.append({"순위": rank, "uid": u, "이름": name, "정의": rec.get("ds_scopenote"),
                      "논문건수": count})
    emit({"검색어": a.term, "후보": cands,
          "안내": "1위를 자동으로 쓰지 마라 — 정의를 보고 사람이 고른다"}, a.out)


EPMC = "https://www.ebi.ac.uk/europepmc/webservices/rest/search"


def cmd_cites(a):
    import datetime as dt
    bad = [p for p in a.pmids if not PMID_RE.match(p)]
    if bad:
        die(f"PMID 형식이 아님: {bad}")
    ids = list(dict.fromkeys(a.pmids))
    this_year = dt.date.today().year
    out = {p: None for p in ids}
    for i in range(0, len(ids), 25):
        chunk = ids[i:i + 25]
        q = "(" + " OR ".join(f"EXT_ID:{p}" for p in chunk) + ") AND (SRC:MED)"
        url = f"{EPMC}?{urllib.parse.urlencode({'query': q, 'format': 'json', 'pageSize': '100', 'resultType': 'lite'})}"
        last = None
        for attempt in range(3):
            try:
                with urllib.request.urlopen(url, timeout=40) as r:
                    data = json.load(r)
                break
            except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as e:
                last = e
                time.sleep(1.5 * (attempt + 1))
        else:
            die(f"Europe PMC 호출 실패: {last}", 4)
        for rec in data.get("resultList", {}).get("result", []):
            pmid = rec.get("pmid") or rec.get("id")
            if pmid not in out:
                continue
            cited = rec.get("citedByCount")
            year = int(rec["pubYear"]) if str(rec.get("pubYear", "")).isdigit() else None
            out[pmid] = {
                "인용수": cited,
                "출판연도": year,
                "연평균인용": round(cited / max(this_year - year, 1), 1) if cited is not None and year else None,
                "오픈액세스": rec.get("isOpenAccess") == "Y",
            }
        time.sleep(0.3)
    emit({"인용": out, "없는PMID": [p for p, v in out.items() if v is None]}, a.out)


def emit(obj, out=None):
    text_ = json.dumps(obj, ensure_ascii=False, indent=2)
    if out:
        os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
        with open(out, "w", encoding="utf-8") as f:
            f.write(text_)
        print(f"→ {out}")
    else:
        print(text_)


def main():
    ap = argparse.ArgumentParser(description="PubMed 조회 (E-utilities)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    for name, fn in (("search", cmd_search), ("count", cmd_count)):
        p = sub.add_parser(name)
        p.add_argument("term")
        p.add_argument("--from", dest="date_from")
        p.add_argument("--to", dest="date_to")
        if name == "search":
            p.add_argument("--max", type=int, default=20)
            p.add_argument("--sort", choices=["relevance", "pub_date"], default="relevance")
        p.add_argument("--out")
        p.set_defaults(fn=fn)

    p = sub.add_parser("fetch")
    p.add_argument("pmids", nargs="+")
    p.add_argument("--out")
    p.set_defaults(fn=cmd_fetch)

    p = sub.add_parser("mesh")
    p.add_argument("uids", nargs="+")
    p.add_argument("--out")
    p.set_defaults(fn=cmd_mesh)

    p = sub.add_parser("check-mesh")
    p.add_argument("keyword")
    p.add_argument("--out")
    p.set_defaults(fn=cmd_check_mesh)

    p = sub.add_parser("cites")
    p.add_argument("pmids", nargs="+")
    p.add_argument("--out")
    p.set_defaults(fn=cmd_cites)

    p = sub.add_parser("mesh-find")
    p.add_argument("term")
    p.add_argument("--max", type=int, default=10)
    p.add_argument("--out")
    p.set_defaults(fn=cmd_mesh_find)

    a = ap.parse_args()
    if a.cmd in ("search", "count") and not a.term.strip():
        die("검색식이 비어 있습니다")
    a.fn(a)


if __name__ == "__main__":
    main()
