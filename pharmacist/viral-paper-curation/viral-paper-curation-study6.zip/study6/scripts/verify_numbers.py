#!/usr/bin/env python3
"""
숫자 환각 차단 검증기.

viral-scorer 가 뽑은 효과크기 인용문(quote)이 실제로 그 논문의 초록에
있는지 PubMed를 다시 조회해 대조한다. LLM은 이 과정에 개입하지 않는다 —
문자열 대조는 파이썬이 하고, 결과가 틀리면 그 슬롯을 null로 지운다.

# 왜 LLM이 아니라 스크립트인가

큐레이션에 적힌 "중성지방 25% 감소"가 실제로 초록에 있는 문장인지는
같은 LLM에게 다시 물어봐도 확인되지 않는다. 처음에 지어냈다면
두 번째도 지어낼 수 있다. 초록 원문을 다시 받아 파이썬 문자열
비교로 대조해야 "있다/없다"가 사실이 된다.

# 사용법

    python3 verify_numbers.py <실행>/과정/점수.json <실행>/과정/점수-검증됨.json

입력 파일의 각 논문 `효과크기.quote` 를 그 논문 PMID의 실제 초록과
대조해 `효과크기.verified` 를 true/false로 채운 뒤 새 파일에 쓴다.
false인 슬롯은 value·unit·quote를 null로 지운다 — 화면에 뭐가
남아있으면 결국 누군가 그걸 읽는다.

출력 파일이 이미 있으면 이어서 검증한다 (재개) — pmid와 quote가
똑같은 슬롯은 다시 조회하지 않는다. 중간에 죽어도, 그때까지 확정된
결과는 이미 파일에 남아 있다 (매 건마다 임시파일→rename으로 갱신).
"""

import json
import os
import re
import sys
import time
import unicodedata
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

EUTILS = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# 초록은 실행이 달라도 같다. 한 번 받은 것은 여기 두고 다시 쓴다 (지워도 된다).
ABSTRACT_CACHE = os.environ.get("ABSTRACT_CACHE") or os.path.join(ROOT, "캐시", "초록")
PMID_RE = re.compile(r"^[0-9]+$")

# 값 앞뒤에 이 문자들이 오면 "다른 숫자의 일부"로 본다.
# "12"가 "120%"나 "112" 안에서 부분문자열로 걸리는 것을 막는다.
# 앞의 "-" 는 부호라서 막는다 ("0.28" 이 "-0.28" 로 통과하면 부호가 뒤집힌다).
# 뒤의 "-" 는 막지 않는다 — "1.5-fold", "1.2-3.4" 의 1.5·1.2 는 그 값 자체다.
_BEFORE_CHARS = "0123456789.,-"
_AFTER_CHARS = "0123456789.,"


def normalize(text):
    """공백류를 전부 일반 공백 하나로 접는다.

    초록 원문에는 얇은 공백(thin space, U+2009)이나 줄바꿈이 섞여
    있다. quote를 뜰 때 이런 문자가 일반 공백으로 바뀌어 있으면
    글자 그대로 비교했을 때 실패한다. 하지만 숫자·단위 자체를
    틀리는 것과 공백 종류가 다른 것은 다른 문제다 — 전자는 잡아야
    하고 후자는 잡을 필요가 없다. 그래서 대조 전에 양쪽을 같은
    방식으로 정규화한다.
    """
    if not isinstance(text, str):
        text = str(text)
    text = unicodedata.normalize("NFKC", text)
    text = text.replace("\u2212", "-")   # 수학 마이너스(−). PubMed 초록에 흔하다
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def normalize_number_text(text):
    """숫자 비교용으로 한 번 더 접는다 — 천단위 구분 쉼표를 없앤다.

    "1,234"와 "1234"는 같은 값의 다른 표기다. 원문 대조(quote가
    초록에 있는지)에는 쉼표를 그대로 두지만, "이 값이 quote 안에
    있는가"를 판정할 때는 표기 차이로 거짓 실패가 나면 안 된다.
    """
    return normalize(text).replace(",", "")


def value_bounded_in(value_str, haystack):
    """value_str 이 haystack 안에 "독립된 숫자"로 있는지 확인한다.

    단순 `in` 검사는 "12"가 "120%"나 "1120" 안에서도 참이 되는
    부분문자열 우회를 허용한다. 앞뒤에 숫자·소수점·쉼표·마이너스가
    붙어 있지 않을 때만 "그 값 자체"로 인정한다.
    """
    escaped = re.escape(value_str)
    pattern = rf"(?<![{re.escape(_BEFORE_CHARS)}]){escaped}(?![{re.escape(_AFTER_CHARS)}])"
    return re.search(pattern, haystack) is not None


# 효과크기를 폐기할 때, 같은 논문의 **설명 문장**에 남은 그 숫자도 가린다.
# 실제로 효과크기 칸은 지웠는데 채점 쪽이 같은 숫자를 `의외성근거` 에도
# 적어 둬서, 큐레이션에 「d=-1.020」이 그대로 실린 적이 있다.
# 가리는 곳은 설명 문장뿐이다 — 제목·대상자·표본 같은 사실 칸은 건드리지 않는다.
REDACT_KEYS = {"의외성근거", "오디언스근거", "근거", "경고이유", "경고"}
REDACTED = "[검증 실패로 지운 숫자]"


def redact_value(paper, value):
    """폐기된 value 를 paper 의 설명 문장에서 가린다. 가린 곳 수를 돌려준다."""
    if not value:
        return 0
    base = str(value).strip().lstrip("-−").strip()
    if not base:
        return 0
    variants = {base, base.replace("·", "."), base.replace(",", "")}
    pats = [re.compile(rf"(?<![0-9.,·]){'[-−]?'}{re.escape(v)}(?![0-9.,·])") for v in variants if v]

    def scrub(x):
        nonlocal count
        if isinstance(x, str):
            for pat in pats:
                x, n = pat.subn(REDACTED, x)
                count += n
            return x
        if isinstance(x, list):
            return [scrub(i) for i in x]
        if isinstance(x, dict):
            return {k: scrub(v) for k, v in x.items()}
        return x

    count = 0
    for k in list(paper):
        if k in REDACT_KEYS:
            paper[k] = scrub(paper[k])
    return count


def fetch_abstract(pmid, api_key=None, retries=3):
    """PMID 하나의 초록을 XML로 재조회한다.

    retmode=text 가 아니라 xml을 쓰는 이유는 p3-paper-hunter.md /
    p4-viral-scorer.md 에 적은 것과 같다 — text 포맷은 얇은 공백을
    바꿔 내보내서 원문 대조가 깨진다.
    """
    if not PMID_RE.match(str(pmid)):
        raise ValueError(f"PMID 형식이 아님: {pmid!r}")

    cached = os.path.join(ABSTRACT_CACHE, f"{pmid}.txt")
    if os.path.exists(cached):
        with open(cached, encoding="utf-8") as f:
            text = normalize(f.read())   # 받을 때와 같은 정규화를 다시 거친다
        if text:
            return text

    params = {
        "db": "pubmed",
        "id": str(pmid),
        "retmode": "xml",
        "rettype": "abstract",
    }
    if api_key:
        params["api_key"] = api_key

    url = f"{EUTILS}/efetch.fcgi?{urllib.parse.urlencode(params)}"

    last_err = None
    for attempt in range(retries):
        try:
            with urllib.request.urlopen(url, timeout=20) as resp:
                data = resp.read()
            root = ET.fromstring(data)
            parts = []
            for ab in root.iter("AbstractText"):
                parts.append("".join(ab.itertext()))
            if root.find(".//PubmedArticle") is None:
                raise LookupError(f"PubMed에 없는 PMID입니다: {pmid}")
            text = normalize(" ".join(parts))
            if text:   # 초록이 없는 논문은 남기지 않는다 — 나중에 초록이 붙을 수 있다
                os.makedirs(ABSTRACT_CACHE, exist_ok=True)
                tmp = f"{cached}.tmp-{os.getpid()}"
                with open(tmp, "w", encoding="utf-8") as f:
                    f.write(text)
                os.replace(tmp, cached)
            return text
        except LookupError:
            raise
        except Exception as e:  # noqa: BLE001 - 네트워크 재시도 목적
            last_err = e
            time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(f"PMID {pmid} 초록 조회 실패: {last_err}")


def verify_slot(slot, abstract_norm):
    """한 효과크기 슬롯을 초록과 대조한다.

    통과 조건 — 전부 참이어야 한다:
      1. quote 전체가 초록의 부분문자열이다
      2. value 가 quote 안에 "독립된 숫자"로 실제로 들어 있다
         (부분문자열 우회 차단 — 아래 참고)
      3. unit 이 있으면, unit 도 quote 안에 있다

    # 부분문자열 우회를 막는 이유

    단순히 `str(value) in quote_norm` 으로 확인하면
    value="12" 가 quote 안의 "120%" 라는 글자에 대해서도 참이
    된다 — "12"라는 숫자가 있는 게 아니라 "120"이라는 다른 숫자의
    일부일 뿐인데 통과한다. 실제로 이 방식으로 재현했다:
    value="12", quote="...120%..." 가 True를 반환했다. value="25",
    unit="mg/dL", quote="...25%..." 도 unit을 아예 안 봐서 True였다.
    이 슬롯이 검증됐다고 큐레이션에 실리면 "12"라는 숫자가 초록에
    있다는 보증이 거짓이 된다.

    그래서 숫자 경계 검사(`value_bounded_in`)로 "다른 숫자의 일부"를
    걸러내고, unit도 반드시 quote 안에서 확인한다.
    """
    quote = slot.get("quote")
    value = slot.get("value")
    unit = slot.get("unit")
    if isinstance(unit, str) and not unit.strip():
        unit = None   # 빈 문자열은 「단위 없음」이다 (MD·SMD 처럼 단위가 없는 효과크기)

    if not isinstance(quote, str) or not quote.strip():
        return False, "quote 없음 또는 문자열이 아님"

    quote_norm = normalize(quote)
    if quote_norm not in abstract_norm:
        return False, "quote가 초록 원문에 없음"

    if value is not None:
        value_str = normalize_number_text(value)
        quote_for_number = quote_norm.replace(",", "")
        if not value_str or not value_bounded_in(value_str, quote_for_number):
            return False, "value가 quote 안에 독립된 숫자로 없음 (다른 숫자의 일부일 수 있음)"

    if unit is not None:
        unit_str = normalize(unit)
        if not unit_str or unit_str not in quote_norm:
            return False, "unit이 quote 안에 없음"

    return True, "일치"


def slot_key(pmid, effect):
    return (str(pmid), json.dumps([effect.get("value"), effect.get("unit"), effect.get("quote")],
                                  ensure_ascii=False))


def load_existing(out_path):
    """이전 실행의 출력 파일에서 **이 스크립트가 판정한 슬롯만** 캐시로 쓴다.

    키는 (pmid, 판정할 때의 value·unit·quote) 다. 채점을 다시 돌려 셋 중 하나라도
    바뀌었으면 새로 검증한다. 판정 표시(`검증`)가 없는 슬롯은 믿지 않는다 —
    처리 도중 끊기면 아직 판정하지 않은 논문도 입력 그대로 출력 파일에 남는데,
    그 안의 `verified: true` 는 채점 에이전트가 적은 값일 수 있다.
    """
    if not os.path.exists(out_path):
        return {}
    try:
        with open(out_path, encoding="utf-8") as f:
            prev = json.load(f)
    except (OSError, json.JSONDecodeError):
        return {}

    cache = {}
    for paper in prev.get("논문", []):
        pmid = paper.get("pmid")
        effect = paper.get("효과크기")
        if not isinstance(effect, dict):
            continue
        mark = effect.get("검증")
        if effect.get("verified") is None or not isinstance(mark, dict):
            continue
        cache[slot_key(pmid, mark.get("입력") or {})] = dict(effect)
    return cache


def atomic_write(path, data):
    """임시파일에 쓰고 rename한다.

    도중에 프로세스가 죽어도 out_path는 "완전히 쓰인 이전 상태"
    또는 "완전히 쓰인 새 상태" 둘 중 하나로만 존재한다. 절반만
    쓰인 JSON이 남아 다음 실행이 파싱에서 죽는 일이 없다.
    """
    tmp_path = f"{path}.tmp-{os.getpid()}"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp_path, path)


def process(data, out_path, api_key=None):
    papers = data.get("논문", [])
    cache = load_existing(out_path)
    seen_pmids = {}
    stats = {"total": 0, "verified": 0, "rejected": 0, "no_claim": 0,
              "cache_hit": 0, "skipped_bad_input": 0}

    for i, paper in enumerate(papers):
        pmid = paper.get("pmid")
        effect = paper.get("효과크기")

        if effect is None:
            stats["no_claim"] += 1
            continue

        if not isinstance(effect, dict):
            print(f"  [경고] pmid={pmid!r}: 효과크기가 dict가 아님 ({type(effect).__name__}) "
                  "— null로 처리", file=sys.stderr)
            paper["효과크기"] = None
            stats["skipped_bad_input"] += 1
            continue

        if not PMID_RE.match(str(pmid or "")):
            print(f"  [경고] PMID 형식이 아님: {pmid!r} — 이 논문 효과크기를 폐기",
                  file=sys.stderr)
            paper["효과크기"] = {"value": None, "unit": None, "quote": None,
                                  "verified": False, "폐기이유": "PMID 형식 오류"}
            stats["skipped_bad_input"] += 1
            continue

        stats["total"] += 1

        cache_key = slot_key(pmid, effect)
        if cache_key in cache:
            paper["효과크기"] = dict(cache[cache_key])
            stats["cache_hit"] += 1
            if paper["효과크기"].get("verified"):
                stats["verified"] += 1
            else:
                stats["rejected"] += 1
                # 폐기 결과를 재사용할 때도 설명 문장의 같은 숫자는 다시 가린다
                hidden = redact_value(paper, effect.get("value"))
                if hidden:
                    stats["redacted"] = stats.get("redacted", 0) + hidden
            atomic_write(out_path, data)
            continue

        judged_input = {"value": effect.get("value"), "unit": effect.get("unit"),
                        "quote": effect.get("quote")}
        mark = {"일시": time.strftime("%Y-%m-%d %H:%M"), "입력": judged_input}

        if pmid not in seen_pmids:
            try:
                seen_pmids[pmid] = fetch_abstract(pmid, api_key=api_key)
            except Exception as e:  # noqa: BLE001
                print(f"  [경고] PMID {pmid} 조회 실패 — 이 논문 효과크기를 폐기: {e}",
                      file=sys.stderr)
                seen_pmids[pmid] = None
            # NCBI_API_KEY 없으면 초당 3회 제한
            time.sleep(0.4 if api_key else 1.0)

        abstract_norm = seen_pmids[pmid]

        if abstract_norm is None:
            ok, reason = False, "초록 조회 실패"
        else:
            ok, reason = verify_slot(effect, abstract_norm)

        if ok:
            effect["verified"] = True
            effect["검증"] = mark
            stats["verified"] += 1
            print(f"  PMID {pmid}: 검증됨 — \"{effect['quote'][:60]}...\"")
        else:
            print(f"  PMID {pmid}: 검증 실패 ({reason}) — 효과크기 폐기")
            hidden = redact_value(paper, effect.get("value"))
            if hidden:
                print(f"    └ 설명 문장에 남은 같은 숫자 {hidden}곳도 가림")
                stats["redacted"] = stats.get("redacted", 0) + hidden
            paper["효과크기"] = {
                "value": None,
                "unit": None,
                "quote": None,
                "verified": False,
                "폐기이유": reason,
                "검증": mark,
            }
            stats["rejected"] += 1

        # 한 건 처리할 때마다 즉시 반영한다 — 중간에 죽어도
        # 여기까지 처리된 결과는 out_path에 이미 남아 있다.
        atomic_write(out_path, data)

    return stats


def summarize(data):
    """brief-writer 가 손으로 세지 않도록, 요약 통계를 스크립트가 만든다.

    최종 큐레이션의 상단 요약표 수치가 실제 JSON과 달랐던 적이 있다
    (근거약함 편수·효과크기 null 편수를 글 쓰는 쪽이 어림잡아 세서
    틀렸다). 그 표에 들어갈 값을 여기서 정확히 계산해 파일에
    같이 실어 둔다. brief-writer 는 이 값을 옮겨 적기만 하면 된다.
    """
    papers = data.get("논문", [])
    total = len(papers)
    no_warning = sum(1 for p in papers if not p.get("경고"))
    # 경고는 라벨만 적는다 — P4.5 스키마 검증이 라벨이 아닌 값을 막는다.
    # 「근거약함 — 이유…」처럼 적은 파일에서 이 칸이 4편인데 1편으로 세어진
    # 적이 있다. 그렇다고 「근거약함으로 시작하면 센다」로 느슨하게 세면
    # 「근거약함 후보로 검토했으나 비적용」 같은 부정문까지 센다. 그래서
    # 라벨이 정확히 일치할 때만 센다.
    has_weak_evidence = sum(1 for p in papers if "근거약함" in (p.get("경고") or []))
    null_effect = sum(
        1 for p in papers
        if p.get("효과크기") is None or not p["효과크기"].get("value")
    )
    return {
        "총_논문수": total,
        "경고_없음": no_warning,
        "근거약함_포함": has_weak_evidence,
        "효과크기_null": null_effect,
    }


def main():
    if len(sys.argv) != 3:
        print(f"사용법: python3 {sys.argv[0]} <입력.json> <출력.json>", file=sys.stderr)
        sys.exit(1)

    in_path, out_path = sys.argv[1], sys.argv[2]

    with open(in_path, encoding="utf-8") as f:
        data = json.load(f)

    papers = data.get("논문", [])
    if not isinstance(papers, list):
        print(f"[오류] '논문' 필드가 배열이 아님: {type(papers).__name__}", file=sys.stderr)
        sys.exit(2)
    if not papers:
        print("논문 목록이 비어 있음 — 그대로 복사", file=sys.stderr)

    api_key = os.environ.get("NCBI_API_KEY")
    if not api_key:
        print("[안내] NCBI_API_KEY 미설정 — 초당 1회로 느리게 진행합니다", file=sys.stderr)

    stats = process(data, out_path, api_key=api_key)
    data["요약"] = summarize(data)
    atomic_write(out_path, data)

    print()
    print(f"완료: 주장 {stats['total']}건 중 검증 {stats['verified']}건, "
          f"폐기 {stats['rejected']}건, 효과크기 없음 {stats['no_claim']}건"
          + (f", 재사용 {stats['cache_hit']}건" if stats["cache_hit"] else "")
          + (f", 형식오류로 폐기 {stats['skipped_bad_input']}건" if stats["skipped_bad_input"] else "")
          + (f", 설명 문장에서 가린 숫자 {stats['redacted']}곳" if stats.get("redacted") else ""))
    print(f"→ {out_path}")

    if stats["rejected"] > 0:
        print(f"[주의] {stats['rejected']}건은 초록에서 확인되지 않아 폐기했습니다. "
              "brief-writer는 이 슬롯의 숫자를 쓰지 않습니다.", file=sys.stderr)


if __name__ == "__main__":
    main()
